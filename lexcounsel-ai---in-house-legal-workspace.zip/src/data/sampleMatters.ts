import { Matter, LegalContract } from '../types/legal';

export const INITIAL_MATTERS: Matter[] = [
  {
    id: 'mat-001',
    matterNumber: 'MAT-2026-0894',
    title: 'CloudCore Enterprise Platform Subscription Agreement (Datavane)',
    practiceArea: 'Commercial & SaaS',
    leadCounsel: 'Eleanor Vance, Deputy General Counsel',
    clientBusinessUnit: 'Cloud Engineering & Infrastructure',
    businessOwner: 'Marcus Brody, VP Infrastructure',
    counterparty: 'Datavane Systems, Inc.',
    status: 'Redlining',
    privilegeLevel: 'ATTORNEY-CLIENT PRIVILEGED',
    riskTolerance: 'Low (Aggressive Protection)',
    createdAt: '2026-03-12',
    targetClosingDate: '2026-04-15',
    dms: {
      provider: 'iManage',
      workspaceId: 'Wksp-CORP-2026-COMM-0894',
      workspaceName: 'COMMERCIAL / 2026 / Datavane Enterprise Cloud',
      documentId: 'iM-DOC-48291-002',
      documentNumber: '#48291.2',
      version: 2,
      isCheckedOut: true,
      checkedOutBy: 'Eleanor Vance (GC Office)',
      lastSyncedAt: '2026-03-28 14:22 EST',
      cabinetOrDatabase: 'ACTIVE_COMMERCIAL_CABINET_US'
    }
  },
  {
    id: 'mat-002',
    matterNumber: 'MAT-2026-0741',
    title: 'Kinesis AI Solutions - Generative Code Model Enterprise Licensing',
    practiceArea: 'IP & Technology',
    leadCounsel: 'Julian Sterling, Senior IP Counsel',
    clientBusinessUnit: 'Core Engineering / Product Org',
    businessOwner: 'Siddharth Rao, Head of DevPlatform',
    counterparty: 'Kinesis AI Labs Ltd.',
    status: 'In Review',
    privilegeLevel: 'ATTORNEY WORK PRODUCT',
    riskTolerance: 'Low (Aggressive Protection)',
    createdAt: '2026-02-18',
    targetClosingDate: '2026-04-30',
    dms: {
      provider: 'NetDocuments',
      workspaceId: 'ND-WS-TECH-9921',
      workspaceName: 'TECH_IP / AI Model Vendor Agreements / Kinesis',
      documentId: 'ND-DOC-9821034-v1',
      documentNumber: '#ND-9821034',
      version: 1,
      isCheckedOut: false,
      lastSyncedAt: '2026-03-27 10:15 EST',
      cabinetOrDatabase: 'ND_GLOBAL_LEGAL_CABINET'
    }
  },
  {
    id: 'mat-003',
    matterNumber: 'MAT-2026-0612',
    title: 'Helion European Cloud - Cross-Border Data Processing Addendum (DPA & SCCs)',
    practiceArea: 'Privacy & Data Security',
    leadCounsel: 'Claire Delacroix, Lead Privacy Counsel (EMEA)',
    clientBusinessUnit: 'Information Security & Compliance',
    businessOwner: 'Astrid Lindholm, Chief Information Security Officer',
    counterparty: 'Helion Cloud GMBH',
    status: 'Vendor Counter',
    privilegeLevel: 'CONFIDENTIAL - IN-HOUSE COUNSEL ONLY',
    riskTolerance: 'Moderate (Balanced)',
    createdAt: '2026-01-20',
    targetClosingDate: '2026-04-10',
    dms: {
      provider: 'iManage',
      workspaceId: 'Wksp-PRIV-2026-EU-0612',
      workspaceName: 'PRIVACY / EMEA Cross-Border Compliance / Helion',
      documentId: 'iM-DOC-31994-003',
      documentNumber: '#31994.3',
      version: 3,
      isCheckedOut: false,
      lastSyncedAt: '2026-03-28 09:40 EST',
      cabinetOrDatabase: 'ACTIVE_COMMERCIAL_CABINET_US'
    }
  }
];

export const SAMPLE_CONTRACTS: Record<string, LegalContract> = {
  'mat-001': {
    id: 'contract-001',
    matterId: 'mat-001',
    title: 'MASTER CLOUD SUBSCRIPTION AGREEMENT (DATAVANE VENDOR FORM)',
    contractType: 'Master Subscription Agreement (MSA)',
    counterparty: 'Datavane Systems, Inc.',
    effectiveDate: '2026-04-01',
    overallRiskScore: 78,
    highRiskCount: 3,
    medRiskCount: 3,
    lowRiskCount: 2,
    version: 'v2.0 (Vendor Draft with In-House Redlines)',
    lastModified: '2026-03-28 14:15 EST',
    content: `MASTER CLOUD SERVICES AGREEMENT

This Master Cloud Services Agreement ("Agreement") is made effective as of April 1, 2026 ("Effective Date"), by and between Datavane Systems, Inc., a Delaware corporation ("Vendor" or "Provider"), and Apex Global Enterprises, Inc., a Delaware corporation ("Customer").

RECITALS
WHEREAS, Provider operates a proprietary real-time distributed telemetry, logging, and data ingestion software-as-a-service platform known as "CloudCore"; and
WHEREAS, Customer desires to subscribe to and utilize the CloudCore platform for its enterprise cloud infrastructure, and Provider agrees to grant such access pursuant to the terms and conditions set forth herein.

NOW, THEREFORE, in consideration of the mutual covenants herein contained, the parties agree as follows:

SECTION 1. DEFINITIONS AND ACCESS
1.1 "Authorized Users" means Customer's employees and independent contractors permitted by Customer to access the Services.
1.2 "Customer Data" means all electronic data, files, logs, or telemetry submitted by or on behalf of Customer into the Services.
1.3 "Service Availability" means Provider will use commercially reasonable efforts to ensure 99.0% uptime, excluding scheduled maintenance.

SECTION 2. FEES, PAYMENT TERMS, AND AUTOMATIC INCREASES
2.1 Payment. Customer shall pay all undisputed invoices within thirty (30) days of receipt.
2.2 Automatic Fee Escalation. Provider reserves the right to increase annual subscription fees by up to fifteen percent (15%) upon each renewal term by providing written electronic notice at least thirty (30) days prior to the expiration of the then-current term. Failure of Customer to terminate within such thirty (30) days shall constitute binding acceptance of the revised fee schedule.

SECTION 3. INTELLECTUAL PROPERTY AND DERIVATIVE DATA RIGHTS
3.1 Customer Data Ownership. As between Customer and Provider, Customer retains all right, title, and interest in and to Customer Data.
3.2 Proprietary Feedback and Model Training Rights. Customer hereby grants Provider a worldwide, perpetual, irrevocable, royalty-free, fully paid-up license to ingest, de-identify, vectorize, and train Provider's internal machine learning heuristics, security models, and artificial intelligence architectures using Customer Data and telemetry. All algorithmic weights, derivative embeddings, and synthetic patterns generated therefrom shall be solely and exclusively owned by Provider.

SECTION 4. WARRANTIES AND EXCLUSIVE REMEDIES
4.1 Limited Warranty. Provider warrants that the Services will perform in material conformity with the online documentation under normal use. Customer's sole and exclusive remedy for any breach of this warranty shall be Provider's commercially reasonable efforts to repair or replace the defective Service within forty-five (45) business days.
4.2 Comprehensive Disclaimer. EXCEPT AS EXPRESSLY PROVIDED IN SECTION 4.1, THE SERVICES ARE PROVIDED "AS IS" AND "AS AVAILABLE." PROVIDER AND ITS SUPPLIERS DISCLAIM ALL OTHER WARRANTIES, WHETHER EXPRESS, IMPLIED, STATUTORY, OR OTHERWISE, INCLUDING ALL WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND NON-INFRINGEMENT. PROVIDER DOES NOT WARRANT THAT THE SERVICE WILL BE UNINTERRUPTED, ACCURATE, OR ERROR-FREE.

SECTION 5. INDEMNIFICATION AND DEFENSE OBLIGATIONS
5.1 Customer Indemnity. Customer shall defend, indemnify, and hold harmless Provider, its affiliates, directors, officers, and employees against any third-party claim, suit, penalty, judgment, loss, or expense (including reasonable attorneys' fees) arising out of or relating to: (a) Customer Data; (b) any allegation that Customer's use of the Services violates applicable law or infringes any third-party intellectual property or privacy right; or (c) Customer's breach of Section 6 (Confidentiality).
5.2 Provider IP Indemnity. Provider shall defend Customer against any claim by an unaffiliated third party alleging that the core Service infringes a registered United States patent or copyright; provided, however, that Provider's total aggregate liability and defense obligations under this Section 5.2 shall be strictly capped at the total amounts paid by Customer to Provider in the preceding three (3) months.

SECTION 6. CONFIDENTIALITY AND PUBLICITY
6.1 Confidentiality. Each party agrees to protect the Confidential Information of the other with the same degree of care it uses for its own confidential materials, but in no event less than reasonable care.
6.2 Publicity & Logo Usage. Provider may publicly name Customer as a client, display Customer's corporate logo and trademarks on Provider's website, promotional pitch decks, and investor presentations, and issue a mandatory joint press release within thirty (30) days of execution without prior written consent.

SECTION 7. LIMITATION OF LIABILITY
7.1 Consequential Damages Waiver. IN NO EVENT SHALL PROVIDER BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, PUNITIVE, OR CONSEQUENTIAL DAMAGES, OR FOR LOSS OF PROFITS, REVENUE, DATA, GOODWILL, WORK STOPPAGE, OR SYSTEM DOWNTIME, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
7.2 Aggregate Financial Cap. PROVIDER'S TOTAL AGGREGATE LIABILITY ARISING OUT OF OR RELATED TO THIS AGREEMENT, WHETHER UNDER CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY, OR ANY OTHER LEGAL OR EQUITABLE THEORY, SHALL BE LIMITED TO THE TOTAL FEES ACTUALLY PAID BY CUSTOMER TO PROVIDER UNDER THE SPECIFIC ORDER FORM GIVING RISE TO LIABILITY IN THE TWELVE (12) MONTH PERIOD PRECEDING THE INCIDENT.
7.3 Carve-outs and Asymmetry. THE LIMITATIONS IN SECTION 7.1 AND SECTION 7.2 SHALL NOT APPLY TO CUSTOMER'S INDEMNIFICATION OBLIGATIONS UNDER SECTION 5.1 OR CUSTOMER'S PAYMENT OBLIGATIONS. PROVIDER'S LIABILITY UNDER SECTION 5.2 (IP INDEMNITY) SHALL REMAIN SUBJECT TO THE SUBCAP SPECIFIED IN SECTION 5.2.

SECTION 8. TERM, TERMINATION, AND AUDIT
8.1 Term and Auto-Renewal. The initial term shall be thirty-six (36) months and shall automatically renew for successive twelve (12) month periods unless either party gives written notice of non-renewal at least ninety (90) days prior to the expiration of the current term.
8.2 Termination for Cause. Either party may terminate this Agreement upon thirty (30) days written notice if the other party materially breaches any provision and fails to cure within sixty (60) days of receipt of written notice.
8.3 Customer Audit. Provider shall have the right, upon seven (7) days advance notice, to conduct an on-site or remote audit of Customer's user access logs and computing environments to verify licensing compliance. Customer shall reimburse Provider for the full cost of the audit if any underpayment exceeds two percent (2%).

SECTION 9. GOVERNING LAW AND EXCLUSIVE JURISDICTION
9.1 Governing Law. This Agreement and any dispute arising hereunder shall be governed exclusively by the laws of the State of Texas, without regard to conflict of law principles.
9.2 Jurisdiction and Venue. The parties consent to the exclusive personal jurisdiction of the state and federal courts located in Travis County, Austin, Texas. Both parties irrevocably waive any right to trial by jury in any action or proceeding arising out of or relating to this Agreement.`,
    clauses: [
      {
        id: 'cl-001',
        title: 'Limitation of Liability - Unilateral Cap & Asymmetric Carve-out',
        category: 'Limitation of Liability',
        clauseNumber: 'Section 7.2 & 7.3',
        lineNumberStart: 49,
        lineNumberEnd: 54,
        riskSeverity: 'HIGH',
        riskSummary: 'Vendor limits its total liability to 12mo trailing fees with a strict sub-cap of 3 months on IP indemnity, while leaving Customer indemnification completely uncapped.',
        playbookStandard: 'Mutual cap equal to 2x annual contract value (or $5M super-cap for IP/data breach), with mutual waivers of consequential damages and reciprocal carve-outs.',
        playbookDeviation: 'Violates Corporate Playbook Rule LL-01: Asymmetrical liability cap and inadequate IP indemnity sub-cap (3 months fees is commercially unreasonable for enterprise patent claims).',
        originalText: `PROVIDER'S TOTAL AGGREGATE LIABILITY ARISING OUT OF OR RELATED TO THIS AGREEMENT, WHETHER UNDER CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY, OR ANY OTHER LEGAL OR EQUITABLE THEORY, SHALL BE LIMITED TO THE TOTAL FEES ACTUALLY PAID BY CUSTOMER TO PROVIDER UNDER THE SPECIFIC ORDER FORM GIVING RISE TO LIABILITY IN THE TWELVE (12) MONTH PERIOD PRECEDING THE INCIDENT.\nTHE LIMITATIONS IN SECTION 7.1 AND SECTION 7.2 SHALL NOT APPLY TO CUSTOMER'S INDEMNIFICATION OBLIGATIONS UNDER SECTION 5.1 OR CUSTOMER'S PAYMENT OBLIGATIONS. PROVIDER'S LIABILITY UNDER SECTION 5.2 (IP INDEMNITY) SHALL REMAIN SUBJECT TO THE SUBCAP SPECIFIED IN SECTION 5.2.`,
        suggestedRedline: {
          proposedText: `EACH PARTY'S TOTAL AGGREGATE LIABILITY ARISING OUT OF OR RELATED TO THIS AGREEMENT SHALL BE LIMITED TO TWO TIMES (2X) THE TOTAL FEES PAID OR PAYABLE BY CUSTOMER TO PROVIDER IN THE TWELVE (12) MONTHS PRECEDING THE CLAIM. NOTWITHSTANDING THE FOREGOING, NEITHER PARTY'S LIABILITY SHALL BE LIMITED WITH RESPECT TO: (A) BREACH OF SECTION 6 (CONFIDENTIALITY); (B) EITHER PARTY'S INDEMNIFICATION OBLIGATIONS UNDER SECTION 5; OR (C) GROSS NEGLIGENCE OR WILLFUL MISCONDUCT. PROVIDER'S AGGREGATE LIABILITY UNDER SECTION 5.2 (IP INDEMNITY) AND FOR DATA SECURITY BREACHES SHALL BE SUBJECT TO A SEPARATE SUPER-CAP OF FIVE MILLION DOLLARS ($5,000,000).`,
          diffMarkup: `<del>PROVIDER'S</del> <ins>EACH PARTY'S</ins> TOTAL AGGREGATE LIABILITY... LIMITED TO <del>TOTAL FEES ACTUALLY PAID... IN THE TWELVE (12) MONTH PERIOD</del> <ins>TWO TIMES (2X) THE TOTAL FEES PAID OR PAYABLE... SUPER-CAP OF $5,000,000 FOR IP INDEMNITY & DATA BREACH</ins>`,
          rationale: 'Restores reciprocity, eliminates the dangerous 3-month IP indemnity sub-cap, and institutes standard 2x cap plus a $5M super-cap for high-exposure IP and data security breaches.',
          fallbackPosition: 'If Vendor refuses 2x ARR cap, accept 1x ARR trailing fees cap ONLY IF accompanied by a $3M super-cap on IP indemnity and gross negligence carve-out.',
          accepted: false
        }
      },
      {
        id: 'cl-002',
        title: 'IP Rights & AI Model Training on Enterprise Customer Data',
        category: 'IP Ownership & Licensing',
        clauseNumber: 'Section 3.2',
        lineNumberStart: 25,
        lineNumberEnd: 29,
        riskSeverity: 'HIGH',
        riskSummary: 'Vendor obtains an irrevocable, perpetual right to ingest and train its proprietary AI/ML models on Customer Data and telemetry, risking enterprise IP leakage and data contamination.',
        playbookStandard: 'Customer Data and telemetry must remain strictly proprietary to Customer. Vendor may only generate aggregated, anonymized operational metrics (not derived from raw payload) solely to operate the platform.',
        playbookDeviation: 'Violates Corporate Playbook Rule IP-03: Strict prohibition on AI/LLM model training, synthetic derivative creation, or vectorization using enterprise customer data.',
        originalText: `Customer hereby grants Provider a worldwide, perpetual, irrevocable, royalty-free, fully paid-up license to ingest, de-identify, vectorize, and train Provider's internal machine learning heuristics, security models, and artificial intelligence architectures using Customer Data and telemetry. All algorithmic weights, derivative embeddings, and synthetic patterns generated therefrom shall be solely and exclusively owned by Provider.`,
        suggestedRedline: {
          proposedText: `Customer does not grant, and Provider shall not acquire, any right or license to ingest, process, vectorize, or utilize Customer Data (or any telemetry derived therefrom) to train, fine-tune, benchmark, or improve any machine learning, artificial intelligence, or algorithmic model. Provider may only collect and analyze generalized, de-identified system performance telemetry solely to maintain and diagnose the operational stability of the Services, provided such telemetry contains no Customer Data or Customer Confidential Information.`,
          diffMarkup: `<del>Customer hereby grants Provider a worldwide, perpetual, irrevocable... license to ingest, de-identify, vectorize, and train Provider's internal machine learning heuristics...</del> <ins>Customer does not grant, and Provider shall not acquire, any right or license to ingest, process, vectorize, or utilize Customer Data to train or fine-tune machine learning or AI models...</ins>`,
          rationale: 'In-house legal policy strictly prohibits enterprise data poisoning or third-party AI training without board-level signoff and CISO review.',
          fallbackPosition: 'Permit statistical operational uptime metrics only (e.g. CPU load, ping latency), with explicit warranty that no customer source code, payloads, or database fields are accessed.',
          accepted: false
        }
      },
      {
        id: 'cl-003',
        title: 'Unilateral Customer Indemnification & Defense Scope',
        category: 'Indemnification',
        clauseNumber: 'Section 5.1 & 5.2',
        lineNumberStart: 36,
        lineNumberEnd: 42,
        riskSeverity: 'HIGH',
        riskSummary: 'Customer must indemnify Vendor for broad categories including alleged law violations and confidentiality breaches, while Vendor IP indemnity is heavily restricted to US patents and capped at 3 months fees.',
        playbookStandard: 'Customer indemnification limited solely to Customer Data directly infringing third-party IP (excluding any Vendor combination claims). Vendor must provide comprehensive uncapped IP indemnity covering patents, copyrights, and trade secrets worldwide.',
        playbookDeviation: 'Violates Corporate Playbook Rule IND-02: Broad unilateral indemnity and sub-capped vendor IP defense obligations.',
        originalText: `Customer shall defend, indemnify, and hold harmless Provider, its affiliates, directors, officers, and employees against any third-party claim, suit, penalty, judgment, loss, or expense (including reasonable attorneys' fees) arising out of or relating to: (a) Customer Data; (b) any allegation that Customer's use of the Services violates applicable law or infringes any third-party intellectual property or privacy right; or (c) Customer's breach of Section 6 (Confidentiality).\nProvider's total aggregate liability and defense obligations under this Section 5.2 shall be strictly capped at the total amounts paid by Customer to Provider in the preceding three (3) months.`,
        suggestedRedline: {
          proposedText: `Customer shall defend Provider against any third-party claim alleging that Customer Data, as provided by Customer and used in strict accordance with this Agreement, infringes a valid copyright or misappropriates a trade secret. Provider shall defend, indemnify, and hold harmless Customer and its officers, directors, and employees against any third-party claim, action, or demand alleging that the Services (or Customer's authorized use thereof) infringes, misappropriates, or violates any patent, copyright, trademark, trade secret, or other proprietary right worldwide. Provider's defense and indemnification obligations under this Section 5.2 shall not be subject to any financial limitation or sub-cap.`,
          diffMarkup: `<del>Customer shall defend, indemnify, and hold harmless Provider... arising out of (b) any allegation that Customer's use violates applicable law...</del> <ins>Customer shall defend Provider against third-party claims alleging Customer Data infringes copyright...</ins> <del>Provider's total aggregate liability... strictly capped at... preceding three (3) months.</del> <ins>Provider shall defend, indemnify, and hold harmless Customer... shall not be subject to any financial limitation or sub-cap.</ins>`,
          rationale: 'Aligns with market standard enterprise SaaS allocation: vendors bear technology IP infringement risk unconditionally; customers only indemnify for their own raw input data.',
          fallbackPosition: 'If Vendor insists on a cap for IP indemnity, require a minimum $10M or 5x ARR super-cap with immediate defense counsel control.',
          accepted: false
        }
      },
      {
        id: 'cl-004',
        title: 'Automatic Fee Escalation (15% Annual Hikes on 30-Day Notice)',
        category: 'Termination & Cure',
        clauseNumber: 'Section 2.2',
        lineNumberStart: 18,
        lineNumberEnd: 21,
        riskSeverity: 'MEDIUM',
        riskSummary: 'Vendor can unilaterally raise pricing by up to 15% each year with only 30 days notice, binding Customer unless Customer terminates in a tight 30-day window.',
        playbookStandard: 'Price lock for the Initial Term. Renewal increases capped at CPI or max 3-5%, requiring at least 60-90 days advance written notice.',
        playbookDeviation: 'Violates Corporate Playbook Rule COM-04: High fee increase cap (15%) and inadequate notice period (30 days gives procurement insufficient time to evaluate alternatives).',
        originalText: `Provider reserves the right to increase annual subscription fees by up to fifteen percent (15%) upon each renewal term by providing written electronic notice at least thirty (30) days prior to the expiration of the then-current term. Failure of Customer to terminate within such thirty (30) days shall constitute binding acceptance of the revised fee schedule.`,
        suggestedRedline: {
          proposedText: `Fees shall remain fixed throughout the Initial Term. Provider may increase fees for any renewal term by no more than the lesser of three percent (3%) or the annual increase in the Consumer Price Index (CPI-U, US All Items), provided that Provider gives Customer written notice of such proposed increase at least ninety (90) days prior to the expiration of the then-current term.`,
          diffMarkup: `...by up to <del>fifteen percent (15%)</del> <ins>the lesser of three percent (3%) or CPI-U</ins>... at least <del>thirty (30)</del> <ins>ninety (90)</ins> days prior to the expiration...`,
          rationale: 'Protects enterprise operational budget predictability and aligns with company procurement benchmarks.',
          fallbackPosition: 'Maximum 5% annual increase with 60 days advance notice.',
          accepted: false
        }
      },
      {
        id: 'cl-005',
        title: 'Unilateral Logo Rights and Mandatory Joint Press Release',
        category: 'Confidentiality',
        clauseNumber: 'Section 6.2',
        lineNumberStart: 45,
        lineNumberEnd: 47,
        riskSeverity: 'MEDIUM',
        riskSummary: 'Vendor reserves right to use Customer trademarks, logos, and issue a mandatory joint press release without prior consent.',
        playbookStandard: 'No public use of Customer name, logo, or trademark without prior written consent of Corporate Communications and Legal.',
        playbookDeviation: 'Violates Corporate Playbook Rule IP-07: Uncontrolled brand publicity.',
        originalText: `Provider may publicly name Customer as a client, display Customer's corporate logo and trademarks on Provider's website, promotional pitch decks, and investor presentations, and issue a mandatory joint press release within thirty (30) days of execution without prior written consent.`,
        suggestedRedline: {
          proposedText: `Neither party shall use the other party's name, logo, or trademarks in any press release, marketing collateral, website, or public disclosure without the prior written approval of the other party's legal department in each specific instance.`,
          diffMarkup: `<del>Provider may publicly name Customer as a client, display Customer's corporate logo... without prior written consent.</del> <ins>Neither party shall use the other party's name, logo, or trademarks without prior written approval of the legal department.</ins>`,
          rationale: 'Standard public company communications policy.',
          fallbackPosition: 'Permit modest text-only customer listing on website vendor roster, but explicitly strike press release and logo display without prior approval.',
          accepted: false
        }
      },
      {
        id: 'cl-006',
        title: 'Governing Law (Texas) and Broad On-Site Audit Rights',
        category: 'Governing Law & Dispute Resolution',
        clauseNumber: 'Section 8.3 & 9.1',
        lineNumberStart: 58,
        lineNumberEnd: 65,
        riskSeverity: 'MEDIUM',
        riskSummary: 'Texas governing law and Travis County venue; aggressive 7-day on-site physical audit rights disrupting engineering operations.',
        playbookStandard: 'Governing law Delaware or New York; audit rights limited to once per calendar year with 30 days notice during normal business hours, remote only.',
        playbookDeviation: 'Violates Corporate Playbook Rule GOV-01: Company corporate seat is Delaware. On-site audit violates datacenter security SOC-2 access rules.',
        originalText: `This Agreement and any dispute arising hereunder shall be governed exclusively by the laws of the State of Texas, without regard to conflict of law principles. The parties consent to the exclusive personal jurisdiction of the state and federal courts located in Travis County, Austin, Texas.\nProvider shall have the right, upon seven (7) days advance notice, to conduct an on-site or remote audit of Customer's user access logs and computing environments...`,
        suggestedRedline: {
          proposedText: `This Agreement shall be governed by and construed in accordance with the laws of the State of Delaware, without giving effect to conflicts of law principles. The parties consent to the exclusive jurisdiction of the state and federal courts sitting in Wilmington, Delaware.\nProvider may, no more than once per twelve (12) month period and upon at least thirty (30) days advance written notice, request Customer to provide certified reporting of active user counts to verify compliance. No physical or on-site access to Customer facilities or production datacenters shall be permitted.`,
          diffMarkup: `...governed exclusively by the laws of the State of <del>Texas</del> <ins>Delaware</ins>... courts located in <del>Travis County, Austin, Texas</del> <ins>Wilmington, Delaware</ins>... audit upon <del>seven (7) days advance notice, on-site or remote</del> <ins>thirty (30) days advance notice, remote certification only, max once per year</ins>`,
          rationale: 'Delaware provides sophisticated chancery court predictability and eliminates datacenter security non-compliance.',
          fallbackPosition: 'Accept New York law if Delaware is rejected; maintain remote certified report requirement.',
          accepted: false
        }
      }
    ],
    riskFlags: [
      {
        id: 'rf-001',
        clauseId: 'cl-001',
        clauseTitle: 'Limitation of Liability',
        sectionNumber: 'Section 7.2',
        severity: 'HIGH',
        issueTitle: 'Asymmetrical Liability Cap & 3-Month IP Indemnity Sub-cap',
        explanation: 'Vendor caps its total damages at 12mo fees, and caps IP defense obligations to 3 months ($37,500), while Customer has unlimited exposure under Section 5.1.',
        financialExposure: 'Estimated exposure: Up to $15,000,000 in patent infringement defense costs and third-party claims.',
        recommendedAction: 'Mandate mutual 2x ARR cap plus $5,000,000 super-cap for IP indemnity and data breaches. Reject 3-month sub-cap completely.',
        playbookRule: 'Rule LL-01: Minimum 2x trailing 12mo spend cap; IP indemnity must be uncapped or subject to minimum $5M super-cap.'
      },
      {
        id: 'rf-002',
        clauseId: 'cl-002',
        clauseTitle: 'AI Model Training on Customer Data',
        sectionNumber: 'Section 3.2',
        severity: 'HIGH',
        issueTitle: 'Perpetual Commercial AI Training License on Enterprise Telemetry',
        explanation: 'Vendor claims perpetual right to ingest, vectorize, and train internal AI/ML models on Customer telemetry, which contains proprietary customer infrastructure logs.',
        financialExposure: 'Unquantified strategic IP leakage, trade secret loss, and breach of customer confidentiality commitments.',
        recommendedAction: 'Strike Section 3.2 in its entirety and substitute company standard AI Non-Ingestion Warranty.',
        playbookRule: 'Rule IP-03: Zero tolerance for vendor model training or vectorization on enterprise customer data.'
      },
      {
        id: 'rf-003',
        clauseId: 'cl-003',
        clauseTitle: 'Unilateral Customer Indemnity',
        sectionNumber: 'Section 5.1',
        severity: 'HIGH',
        issueTitle: 'Customer Indemnifies Vendor for Law Violations & Broad Third-Party Claims',
        explanation: 'Customer is forced to indemnify Vendor for generic claims including Customer use of the platform alleged to violate applicable law.',
        financialExposure: 'Significant litigation exposure in regulatory and compliance disputes.',
        recommendedAction: 'Narrow Customer indemnity strictly to Customer Data infringing copyright or trade secrets. Require reciprocal full IP indemnity from Vendor.',
        playbookRule: 'Rule IND-02: Customer indemnity must be strictly limited to raw customer data infringement.'
      },
      {
        id: 'rf-004',
        clauseId: 'cl-004',
        clauseTitle: 'Automatic Fee Increases',
        sectionNumber: 'Section 2.2',
        severity: 'MEDIUM',
        issueTitle: '15% Annual Escalator on Short 30-Day Notice',
        explanation: 'Allows vendor to impose 15% compounding annual increases with minimal 30-day notice, trapping enterprise in unwanted fee hikes.',
        financialExposure: '$150,000+ compounding increase over 3 years.',
        recommendedAction: 'Cap increases at CPI or 3% max, requiring 90 days advance written notice.',
        playbookRule: 'Rule COM-04: Max 3-5% escalation with 90-day notification.'
      },
      {
        id: 'rf-005',
        clauseId: 'cl-005',
        clauseTitle: 'Unilateral Publicity Rights',
        sectionNumber: 'Section 6.2',
        severity: 'MEDIUM',
        issueTitle: 'Mandatory Press Release & Uncontrolled Logo Use',
        explanation: 'Vendor claims right to issue a joint press release and use corporate marks without prior written approval.',
        financialExposure: 'Reputational risk and violation of internal brand guidelines.',
        recommendedAction: 'Make all publicity subject to prior written approval from Corporate Communications.',
        playbookRule: 'Rule IP-07: Prior written consent required for all logo and press release usage.'
      },
      {
        id: 'rf-006',
        clauseId: 'cl-006',
        clauseTitle: 'Governing Law & Audit Rights',
        sectionNumber: 'Section 8.3 & 9.1',
        severity: 'MEDIUM',
        issueTitle: 'Texas Venue and 7-Day On-Site Physical Audit Access',
        explanation: 'Venue in Travis County, TX; allows intrusive physical inspection of datacenters violating SOC-2 security protocols.',
        financialExposure: 'Audit compliance disruption, potential SOC-2 finding, out-of-state litigation expense.',
        recommendedAction: 'Switch to Delaware Chancery Court; limit audit to annual certified self-reporting with 30-day notice.',
        playbookRule: 'Rule GOV-01: Delaware or NY law preferred; remote audit verification only.'
      }
    ]
  },
  'mat-002': {
    id: 'contract-002',
    matterId: 'mat-002',
    title: 'ENTERPRISE AI MODEL LICENSING & INFERENCE AGREEMENT (KINESIS)',
    contractType: 'AI Technology Licensing Agreement',
    counterparty: 'Kinesis AI Labs Ltd.',
    effectiveDate: '2026-05-01',
    overallRiskScore: 84,
    highRiskCount: 4,
    medRiskCount: 2,
    lowRiskCount: 1,
    version: 'v1.0 (Initial Vendor Draft)',
    lastModified: '2026-03-27 10:15 EST',
    content: `ENTERPRISE AI MODEL LICENSING AND INFERENCE SERVICES AGREEMENT

This Agreement is entered into by and between Kinesis AI Labs Ltd. ("Kinesis") and Apex Global Enterprises, Inc. ("Enterprise").

1. LICENSED MODELS AND INFERENCE API
Kinesis grants Enterprise a non-exclusive license to access Kinesis Foundation LLM-70B and Specialized Code Generation models via dedicated inference endpoints.

2. TRAINING DATA AND MODEL FINE-TUNING RETENTION
2.1 Fine-Tuning Artifacts. In the event Enterprise provides custom source code, documentation, or internal software repositories to fine-tune the models, Kinesis shall retain co-ownership of all merged checkpoint weights, adapter layers (LoRA/QLoRA), and embedding indexes.
2.2 Model Evolution. Kinesis may incorporate generalizable code syntax abstractions derived from Enterprise prompts into the base foundational training corpus for future commercial versions of the Kinesis model family.

3. IP INFRINGEMENT AND OUTPUT INDEMNITY
3.1 Output As-Is. Enterprise acknowledges that generative AI models produce probabilistic outputs. KINESIS PROVIDES ALL MODEL OUTPUTS "AS IS" AND DISCLAIMS ALL WARRANTIES REGARDING NON-INFRINGEMENT OF THIRD-PARTY COPYRIGHTS, PATENTS, OR OPEN SOURCE LICENSES (E.G., GPL, AGPL) IN GENERATED CODE.
3.2 Customer Defense of Third-Party Claims. Enterprise shall indemnify Kinesis from any third-party claims arising from Enterprise's deployment, compilation, or commercial distribution of software code generated by the Services.

4. LIMITATION OF LIABILITY
Neither party shall be liable for indirect damages. Kinesis's aggregate liability under this agreement is capped at five thousand dollars ($5,000).

5. GOVERNING LAW
Governing law shall be the laws of England and Wales with arbitration in London under LCIA rules.`,
    clauses: [
      {
        id: 'cl-201',
        title: 'Co-Ownership of Fine-Tuned Model Weights & Adapters',
        category: 'IP Ownership & Licensing',
        clauseNumber: 'Section 2.1',
        lineNumberStart: 8,
        lineNumberEnd: 11,
        riskSeverity: 'HIGH',
        riskSummary: 'Vendor claims co-ownership of LoRA adapters and fine-tuned model checkpoints created using Customer proprietary source code.',
        playbookStandard: 'Customer must retain sole, exclusive ownership of all fine-tuned checkpoints, LoRA adapters, system prompts, and custom embeddings.',
        playbookDeviation: 'Violates Corporate Playbook Rule IP-AI-01: Vendor co-ownership of fine-tuned weights creates immediate trade secret contamination.',
        originalText: `In the event Enterprise provides custom source code, documentation, or internal software repositories to fine-tune the models, Kinesis shall retain co-ownership of all merged checkpoint weights, adapter layers (LoRA/QLoRA), and embedding indexes.`,
        suggestedRedline: {
          proposedText: `All fine-tuned model weights, LoRA adapters, hyper-parameters, vector embeddings, and derivative model checkpoints trained or fine-tuned using Enterprise source code or data ("Customer AI Artifacts") shall be the sole and exclusive property of Enterprise. Kinesis shall not retain, copy, or use Customer AI Artifacts for any other customer or purpose, and shall permanently delete all such artifacts upon termination.`,
          diffMarkup: `<del>Kinesis shall retain co-ownership of all merged checkpoint weights...</del> <ins>All fine-tuned model weights... shall be the sole and exclusive property of Enterprise...</ins>`,
          rationale: 'Ensures that proprietary software algorithms fine-tuned into models cannot be re-used or accessed by competitors.',
          fallbackPosition: 'Exclusive license to Customer with perpetual restriction preventing Kinesis from exposing weights.',
          accepted: false
        }
      },
      {
        id: 'cl-202',
        title: 'Generative Output IP Infringement Disclaimer (No Copyright Defense)',
        category: 'Warranties & Disclaimers',
        clauseNumber: 'Section 3.1 & 3.2',
        lineNumberStart: 13,
        lineNumberEnd: 18,
        riskSeverity: 'HIGH',
        riskSummary: 'Vendor disclaims all copyright and open source copyleft infringement in AI-generated code, forcing Customer to defend Vendor instead.',
        playbookStandard: 'Vendor must provide generative AI copyright indemnity defending Customer against claims that generated code infringes third-party copyright, trade secrets, or open source licenses (backed by indemnification pledge like GitHub Copilot/Google Cloud AI indemnification).',
        playbookDeviation: 'Violates Corporate Playbook Rule AI-IND-01: AI vendor must defend enterprise against third-party copyright infringement resulting from model pre-training corpus.',
        originalText: `KINESIS PROVIDES ALL MODEL OUTPUTS "AS IS" AND DISCLAIMS ALL WARRANTIES REGARDING NON-INFRINGEMENT OF THIRD-PARTY COPYRIGHTS, PATENTS, OR OPEN SOURCE LICENSES... Enterprise shall indemnify Kinesis from any third-party claims arising from Enterprise's deployment...`,
        suggestedRedline: {
          proposedText: `Kinesis warrants that the Models and Outputs do not and will not infringe, misappropriate, or violate any third-party intellectual property right, copyright, or open source license. Kinesis shall defend, indemnify, and hold harmless Enterprise against any third-party claim alleging that the Model or generated Output infringes any patent, copyright, or trade secret, provided Enterprise utilized Kinesis's built-in code reference filtering tools.`,
          diffMarkup: `<del>KINESIS PROVIDES ALL MODEL OUTPUTS 'AS IS' AND DISCLAIMS ALL WARRANTIES...</del> <ins>Kinesis warrants that the Models and Outputs will not infringe third-party IP and provides full copyright indemnity...</ins>`,
          rationale: 'Aligns with enterprise generative AI procurement standards established by Microsoft, Google, and Amazon.',
          fallbackPosition: 'Indemnity limited to unmodified outputs where filtering features were enabled.',
          accepted: false
        }
      },
      {
        id: 'cl-203',
        title: 'Unreasonable $5,000 Liability Cap',
        category: 'Limitation of Liability',
        clauseNumber: 'Section 4',
        lineNumberStart: 20,
        lineNumberEnd: 22,
        riskSeverity: 'HIGH',
        riskSummary: 'Vendor caps liability at an absurd $5,000 for an enterprise contract covering mission-critical software development.',
        playbookStandard: 'Liability cap equal to 2x annual contract value, with carve-outs for IP indemnity, confidentiality, and data breach.',
        playbookDeviation: 'Violates Corporate Playbook Rule LL-02: Nominal liability caps ($5k) are unacceptable for enterprise tier software.',
        originalText: `Kinesis's aggregate liability under this agreement is capped at five thousand dollars ($5,000).`,
        suggestedRedline: {
          proposedText: `Each party's total aggregate liability arising under this Agreement shall be capped at the total amount paid by Enterprise in the preceding twelve (12) months; provided, however, that neither party's liability for breach of confidentiality, IP indemnification obligations, or gross negligence shall be subject to any financial limitation.`,
          diffMarkup: `...is capped at <del>five thousand dollars ($5,000)</del> <ins>the total amount paid in the preceding twelve (12) months, with uncapped carve-outs for IP indemnity and confidentiality</ins>.`,
          rationale: 'Eliminates illusion of contractual recourse.',
          fallbackPosition: 'Minimum $1M liability cap.',
          accepted: false
        }
      }
    ],
    riskFlags: [
      {
        id: 'rf-201',
        clauseId: 'cl-201',
        clauseTitle: 'IP Ownership',
        sectionNumber: 'Section 2.1',
        severity: 'HIGH',
        issueTitle: 'Vendor Co-Ownership of Custom Fine-Tuned AI Weights',
        explanation: 'Kinesis claims co-ownership over all adapter weights created from Enterprise internal source code, creating severe trade secret exposure.',
        financialExposure: 'Potential loss of proprietary enterprise codebases and competitive differentiation.',
        recommendedAction: 'Demand 100% exclusive ownership of all fine-tuned artifacts and LoRA layers.',
        playbookRule: 'Rule IP-AI-01: Enterprise must own all custom-trained weights and adapters.'
      },
      {
        id: 'rf-202',
        clauseId: 'cl-202',
        clauseTitle: 'Warranties & Output Indemnity',
        sectionNumber: 'Section 3.1',
        severity: 'HIGH',
        issueTitle: 'No Copyright Indemnification for AI Generated Code',
        explanation: 'Vendor refuses to defend against code copyright infringement or open source copyleft violations (e.g. GPL contaminations).',
        financialExposure: 'Exposure to open-source licensing lawsuits, mandatory code disclosure, and copyright statutory damages ($150k per work).',
        recommendedAction: 'Insist on standard commercial GenAI copyright defense clause.',
        playbookRule: 'Rule AI-IND-01: GenAI vendor must provide output copyright indemnification.'
      }
    ]
  },
  'mat-003': {
    id: 'contract-003',
    matterId: 'mat-003',
    title: 'CROSS-BORDER DATA PROCESSING ADDENDUM (HELION EU CLOUD)',
    contractType: 'Data Processing Addendum (DPA & SCCs)',
    counterparty: 'Helion Cloud GMBH',
    effectiveDate: '2026-01-15',
    overallRiskScore: 52,
    highRiskCount: 1,
    medRiskCount: 3,
    lowRiskCount: 2,
    version: 'v3.0 (EMEA Privacy Redline)',
    lastModified: '2026-03-28 09:35 EST',
    content: `DATA PROCESSING ADDENDUM (GDPR / STANDARD CONTRACTUAL CLAUSES)

Between Helion Cloud GMBH ("Data Importer" or "Processor") and Apex Global Enterprises, Inc. ("Data Exporter" or "Controller").

1. SCOPE AND NATURE OF PROCESSING
Processor processes personal data solely on documented instructions of Controller, as set forth in Schedule 1.

2. SUBPROCESSOR NOTIFICATION AND REJECTION TIMELINE
Processor may engage third-party sub-processors. Processor shall maintain an online list of subprocessors. Processor will provide notice of new subprocessors via email list ten (10) calendar days prior to granting access. Controller must object within seven (7) days, or consent shall be conclusively presumed. If Controller objects, Controller's sole remedy is to terminate the underlying agreement with payment of all remaining contract fees.

3. SECURITY INCIDENT NOTIFICATION
Processor shall notify Controller of any confirmed personal data breach without undue delay, and in any event within seventy-two (72) hours of Processor's internal security team verifying the breach.

4. AUDIT AND INSPECTION
Processor will make available SOC-2 Type II audit reports annually. Any on-premise inspection shall require Controller to pay Processor an audit fee of €10,000 per day.

5. LIABILITY UNDER DPA
Processor's aggregate liability under this DPA shall be subject to the limitation of liability set forth in the Principal Agreement.`,
    clauses: [
      {
        id: 'cl-301',
        title: 'Unreasonable Subprocessor Objection Terms & Termination Penalties',
        category: 'Data Privacy & Security',
        clauseNumber: 'Section 2',
        lineNumberStart: 7,
        lineNumberEnd: 11,
        riskSeverity: 'HIGH',
        riskSummary: '10-day notice and 7-day objection window for new subprocessors; if Controller objects, Controller must pay full remaining contract fees.',
        playbookStandard: 'Minimum 30 days advance written notice of new subprocessors. Controller has right to terminate without penalty or termination fee if legitimate security/privacy objection cannot be resolved.',
        playbookDeviation: 'Violates Corporate Playbook Rule PRIV-02: Penalizing Controller for exercising GDPR Art. 28 subprocessor objection rights is non-compliant.',
        originalText: `Processor will provide notice of new subprocessors via email list ten (10) calendar days prior to granting access. Controller must object within seven (7) days... Controller's sole remedy is to terminate the underlying agreement with payment of all remaining contract fees.`,
        suggestedRedline: {
          proposedText: `Processor shall provide at least thirty (30) days advance written notice before engaging any new sub-processor. If Controller reasonably objects on data protection grounds within thirty (30) days of such notice, Processor shall use reasonable efforts to offer an alternative configuration. If no alternative is feasible within thirty (30) days, Controller may terminate the affected Services without penalty, liability, or payment of any remaining unearned fees.`,
          diffMarkup: `...notice at least <del>ten (10) calendar days</del> <ins>thirty (30) days advance written notice</ins>... Controller may terminate <del>with payment of all remaining contract fees</del> <ins>without penalty, liability, or payment of unearned fees</ins>.`,
          rationale: 'Complies with GDPR Article 28 mandatory controller instructions and eliminates punitive exit penalties.',
          fallbackPosition: 'Minimum 20-day notice with refund of prepaid unused fees.',
          accepted: false
        }
      }
    ],
    riskFlags: [
      {
        id: 'rf-301',
        clauseId: 'cl-301',
        clauseTitle: 'Subprocessor Objection Penalty',
        sectionNumber: 'Section 2',
        severity: 'HIGH',
        issueTitle: 'Termination Penalties for GDPR Subprocessor Objection',
        explanation: 'Forces Customer to pay all remaining contract fees if objecting to an insecure subprocessor.',
        financialExposure: 'Up to €450,000 in accelerated contract payout.',
        recommendedAction: 'Mandate 30-day notice and penalty-free exit upon unresolved security objection.',
        playbookRule: 'Rule PRIV-02: Subprocessor objection must allow penalty-free termination.'
      }
    ]
  }
};
