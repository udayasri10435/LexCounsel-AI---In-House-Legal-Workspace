export interface PlaybookRule {
  ruleCode: string;
  category: string;
  title: string;
  standardPosition: string;
  minimumAcceptableFallback: string;
  dealBreakers: string[];
  samplePreferredLanguage: string;
}

export const CORPORATE_LEGAL_PLAYBOOK: PlaybookRule[] = [
  {
    ruleCode: 'LL-01',
    category: 'Limitation of Liability',
    title: 'Liability Caps & Carve-Outs',
    standardPosition: 'Mutual cap equal to 2x trailing 12 months fees paid or payable. Uncapped carve-outs for breach of confidentiality, IP indemnification, gross negligence/willful misconduct, and a separate $5,000,000 super-cap for data security breaches.',
    minimumAcceptableFallback: '1x trailing 12 months fees cap, provided IP indemnity is uncapped or subject to at least $3,000,000 super-cap.',
    dealBreakers: [
      'Unilateral vendor-only liability cap',
      'Vendor liability capped under $1M for enterprise tier systems',
      'Carve-outs that only favor the vendor while leaving customer indemnities uncapped'
    ],
    samplePreferredLanguage: `EACH PARTY'S TOTAL AGGREGATE LIABILITY ARISING OUT OF OR RELATED TO THIS AGREEMENT SHALL BE LIMITED TO TWO TIMES (2X) THE TOTAL FEES PAID OR PAYABLE BY CUSTOMER IN THE TWELVE (12) MONTHS PRECEDING THE CLAIM. NOTWITHSTANDING THE FOREGOING, NEITHER PARTY'S LIABILITY SHALL BE LIMITED FOR: (A) BREACH OF CONFIDENTIALITY; (B) INDEMNIFICATION OBLIGATIONS; OR (C) GROSS NEGLIGENCE OR WILLFUL MISCONDUCT.`
  },
  {
    ruleCode: 'IP-03',
    category: 'IP Ownership & Licensing',
    title: 'Customer Data & AI Model Training Prohibition',
    standardPosition: 'Customer retains 100% exclusive ownership of all Customer Data, inputs, outputs, prompts, and custom fine-tuned weights. Vendor strictly prohibited from using data to train, fine-tune, or benchmark any multi-tenant AI/ML model.',
    minimumAcceptableFallback: 'Vendor may use strictly aggregated system operational telemetry (e.g. CPU, latency) containing no Customer Data or metadata.',
    dealBreakers: [
      'Perpetual license to vendor to ingest data for AI/ML training',
      'Vendor co-ownership of fine-tuned model weights or LoRA adapters',
      'Broad data harvesting clauses'
    ],
    samplePreferredLanguage: `Customer retains all right, title, and interest in and to Customer Data. Provider shall not use Customer Data, telemetry, or outputs to train, fine-tune, or improve any machine learning, artificial intelligence, or algorithmic models.`
  },
  {
    ruleCode: 'IND-02',
    category: 'Indemnification',
    title: 'Vendor IP Defense & Customer Indemnity Scope',
    standardPosition: 'Vendor must defend, indemnify, and hold harmless Customer against all third-party claims that the Services infringe any patent, copyright, or trade secret worldwide, without sub-caps. Customer indemnification strictly limited to Customer Data infringing third-party IP.',
    minimumAcceptableFallback: 'Vendor IP indemnity subject to super-cap of not less than $5M or 5x annual fees.',
    dealBreakers: [
      'Vendor sub-caps IP defense to 3 or 6 months of fees',
      'Customer required to indemnify vendor for general law violations or regulatory actions',
      'No obligation for vendor to defend or provide replacement software'
    ],
    samplePreferredLanguage: `Provider shall defend, indemnify, and hold harmless Customer from any third-party claim alleging that Customer's authorized use of the Services infringes or misappropriates any third-party patent, copyright, or trade secret worldwide.`
  },
  {
    ruleCode: 'COM-04',
    category: 'Termination & Cure',
    title: 'Fee Escalations & Auto-Renewal',
    standardPosition: 'Prices locked for initial term. Subsequent annual renewal price increases capped at the lesser of 3% or CPI-U, with minimum 90 days advance written notice.',
    minimumAcceptableFallback: 'Max 5% increase with 60 days advance written notice and right to terminate without penalty.',
    dealBreakers: [
      'Uncapped fee increases on short notice',
      'Automatic renewal with less than 30 days notice to opt-out',
      'Accelerated fee penalties upon early termination for convenience'
    ],
    samplePreferredLanguage: `Subscription fees shall remain fixed for the Initial Term. Any renewal fee increase shall not exceed the lesser of three percent (3%) or CPI-U, upon at least ninety (90) days advance written notice.`
  },
  {
    ruleCode: 'GOV-01',
    category: 'Governing Law & Dispute Resolution',
    title: 'Governing Law & Jurisdiction',
    standardPosition: 'Delaware law and exclusive jurisdiction of Delaware Chancery Court and Federal District Court in Wilmington, DE.',
    minimumAcceptableFallback: 'New York law and courts located in New York County (Manhattan).',
    dealBreakers: [
      'Foreign jurisdiction outside US without local counsel approval',
      'Mandatory binding arbitration with waiver of preliminary injunctive relief'
    ],
    samplePreferredLanguage: `This Agreement shall be governed by the laws of the State of Delaware without regard to conflict of law principles. The parties consent to exclusive jurisdiction in Wilmington, Delaware.`
  }
];
