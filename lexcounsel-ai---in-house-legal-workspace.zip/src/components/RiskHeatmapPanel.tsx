import React, { useState } from 'react';
import { 
  AlertTriangle, 
  ShieldAlert, 
  CheckCircle2, 
  BookOpen, 
  Copy, 
  Check, 
  Sparkles, 
  ChevronRight, 
  DollarSign, 
  FileText, 
  Scale, 
  Flame,
  ArrowRight,
  Filter,
  Layers,
  ChevronDown
} from 'lucide-react';
import { LegalContract, Clause, RiskSeverity, Precedent } from '../types/legal';

interface RiskHeatmapPanelProps {
  contract: LegalContract;
  activeClauseId: string | null;
  onSelectClause: (clauseId: string) => void;
  onAcceptRedline: (clauseId: string) => void;
  onOpenPrecedentDetail: (precedent: Precedent) => void;
  onOpenPrecedentsModal: () => void;
  precedents: Precedent[];
}

export const RiskHeatmapPanel: React.FC<RiskHeatmapPanelProps> = ({
  contract,
  activeClauseId,
  onSelectClause,
  onAcceptRedline,
  onOpenPrecedentDetail,
  onOpenPrecedentsModal,
  precedents,
}) => {
  const [severityFilter, setSeverityFilter] = useState<'ALL' | RiskSeverity>('ALL');
  const [showFallback, setShowFallback] = useState(false);
  const [copiedRedline, setCopiedRedline] = useState(false);

  const activeClause = contract.clauses.find(c => c.id === activeClauseId) || contract.clauses[0];

  const filteredClauses = contract.clauses.filter(clause => {
    if (severityFilter === 'ALL') return true;
    return clause.riskSeverity === severityFilter;
  });

  // Find related precedents for the active clause category
  const matchingPrecedents = precedents.filter(p => 
    p.clauseCategory.toLowerCase().includes(activeClause?.category.toLowerCase() || '') ||
    activeClause?.category.toLowerCase().includes(p.clauseCategory.toLowerCase() || '')
  );

  const handleCopyRedline = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedRedline(true);
    setTimeout(() => setCopiedRedline(false), 2000);
  };

  const getScoreColor = (score: number) => {
    if (score >= 70) return 'text-rose-400 bg-rose-950/60 border-rose-700/60';
    if (score >= 40) return 'text-amber-400 bg-amber-950/60 border-amber-700/60';
    return 'text-emerald-400 bg-emerald-950/60 border-emerald-700/60';
  };

  return (
    <div className="w-full lg:w-[480px] xl:w-[520px] bg-slate-900 border-l border-slate-800 flex flex-col h-full overflow-hidden text-slate-200">
      {/* Risk Score & Posture Header */}
      <div className="p-4 bg-slate-950 border-b border-slate-800">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-indigo-400" />
            <h2 className="font-bold text-sm text-white">Risk Heatmap & Playbook Audit</h2>
          </div>
          <span className="text-[11px] text-slate-400 font-mono">
            {contract.clauses.filter(c => c.suggestedRedline.accepted).length} of {contract.clauses.length} Mitigated
          </span>
        </div>

        {/* Risk Score Card */}
        <div className="flex items-center gap-4 p-3 rounded-lg bg-slate-900 border border-slate-800">
          <div className={`w-16 h-16 rounded-xl flex flex-col items-center justify-center border font-bold ${getScoreColor(contract.overallRiskScore)}`}>
            <span className="text-xl leading-none">{contract.overallRiskScore}</span>
            <span className="text-[9px] uppercase tracking-wider mt-0.5">/ 100</span>
          </div>

          <div className="flex-1">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold text-white">
                {contract.overallRiskScore >= 70 ? 'High Contractual Exposure' :
                 contract.overallRiskScore >= 40 ? 'Moderate Commercial Risk' :
                 'Compliant / Low Risk'}
              </span>
              <span className="text-[11px] text-slate-400">GC Sign-off: Required</span>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden mb-2">
              <div 
                className={`h-full transition-all duration-500 ${
                  contract.overallRiskScore >= 70 ? 'bg-rose-500' :
                  contract.overallRiskScore >= 40 ? 'bg-amber-500' :
                  'bg-emerald-500'
                }`}
                style={{ width: `${contract.overallRiskScore}%` }}
              />
            </div>

            {/* Severity Pill Counts */}
            <div className="flex items-center gap-3 text-[11px]">
              <span className="flex items-center gap-1 text-rose-300">
                <span className="w-2 h-2 rounded-full bg-rose-500" />
                <strong>{contract.highRiskCount}</strong> High
              </span>
              <span className="flex items-center gap-1 text-amber-300">
                <span className="w-2 h-2 rounded-full bg-amber-500" />
                <strong>{contract.medRiskCount}</strong> Medium
              </span>
              <span className="flex items-center gap-1 text-emerald-300">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                <strong>{contract.lowRiskCount}</strong> Low
              </span>
            </div>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center gap-1 mt-3">
          {(['ALL', 'HIGH', 'MEDIUM', 'LOW'] as const).map((sev) => (
            <button
              key={sev}
              onClick={() => setSeverityFilter(sev)}
              className={`px-2.5 py-1 rounded text-[11px] font-semibold transition-colors cursor-pointer ${
                severityFilter === sev
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {sev === 'ALL' ? 'All Deviations' : `${sev} Risk`}
            </button>
          ))}
        </div>
      </div>

      {/* Clause Selector Tabs (Horizontal Mini Strip) */}
      <div className="bg-slate-950/70 border-b border-slate-800/80 px-4 py-2 flex items-center gap-1.5 overflow-x-auto text-xs">
        {filteredClauses.map((clause) => {
          const isSelected = clause.id === activeClause?.id;
          return (
            <button
              key={clause.id}
              onClick={() => onSelectClause(clause.id)}
              className={`px-3 py-1 rounded-md text-xs font-medium whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer border ${
                isSelected
                  ? 'bg-indigo-600 text-white border-indigo-400 shadow'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border-slate-800'
              }`}
            >
              <span className={`w-1.5 h-1.5 rounded-full ${
                clause.riskSeverity === 'HIGH' ? 'bg-rose-400' :
                clause.riskSeverity === 'MEDIUM' ? 'bg-amber-400' :
                'bg-emerald-400'
              }`} />
              <span>{clause.clauseNumber}</span>
              {clause.suggestedRedline.accepted && (
                <Check className="w-3 h-3 text-emerald-400" />
              )}
            </button>
          );
        })}
      </div>

      {/* Active Clause Inspection Card */}
      {activeClause ? (
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Active Clause Header & Title */}
          <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider font-mono">
                {activeClause.clauseNumber} • {activeClause.category}
              </span>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                activeClause.riskSeverity === 'HIGH' ? 'bg-rose-950 text-rose-300 border border-rose-700/80' :
                activeClause.riskSeverity === 'MEDIUM' ? 'bg-amber-950 text-amber-300 border border-amber-700/80' :
                'bg-emerald-950 text-emerald-300 border border-emerald-700/80'
              }`}>
                {activeClause.riskSeverity} RISK
              </span>
            </div>
            <h3 className="font-bold text-sm text-white leading-snug">
              {activeClause.title}
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              {activeClause.riskSummary}
            </p>
          </div>

          {/* Corporate Playbook Standard vs Deviation */}
          <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-200">
              <Scale className="w-4 h-4 text-indigo-400" />
              <span>Playbook Benchmark & Deviation</span>
            </div>

            <div className="space-y-2 text-xs">
              <div className="p-2.5 rounded bg-slate-900 border border-slate-800">
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 block mb-1">
                  Company Playbook Standard:
                </span>
                <p className="text-slate-300 leading-relaxed font-sans">
                  {activeClause.playbookStandard}
                </p>
              </div>

              <div className="p-2.5 rounded bg-rose-950/30 border border-rose-900/50">
                <span className="text-[10px] font-bold uppercase tracking-wider text-rose-400 block mb-1">
                  Incoming Vendor Deviation:
                </span>
                <p className="text-rose-200/90 leading-relaxed font-sans">
                  {activeClause.playbookDeviation}
                </p>
              </div>
            </div>
          </div>

          {/* AI Recommended In-House Redline */}
          <div className="p-3.5 rounded-lg bg-indigo-950/30 border border-indigo-800/60 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-indigo-400" />
                <span className="text-xs font-bold text-white">In-House Redline (Primary Proposal)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => handleCopyRedline(activeClause.suggestedRedline.proposedText)}
                  className="p-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-xs transition-colors cursor-pointer"
                  title="Copy redline text"
                >
                  {copiedRedline ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                </button>
              </div>
            </div>

            {/* Redline Text Box with track-changes styling */}
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono leading-relaxed text-emerald-300 whitespace-pre-wrap selection:bg-emerald-800 selection:text-white">
              {activeClause.suggestedRedline.proposedText}
            </div>

            {/* Negotiation Rationale */}
            <div className="text-xs space-y-1">
              <span className="font-semibold text-slate-300">Negotiation Rationale:</span>
              <p className="text-slate-400 leading-relaxed">
                {activeClause.suggestedRedline.rationale}
              </p>
            </div>

            {/* Secondary Fallback Position Toggle */}
            <div className="pt-2 border-t border-indigo-900/50">
              <button
                onClick={() => setShowFallback(!showFallback)}
                className="flex items-center justify-between w-full text-xs font-medium text-indigo-300 hover:text-indigo-200 transition-colors cursor-pointer"
              >
                <span>Secondary Fallback Position (If Vendor Rejects)</span>
                <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showFallback ? 'rotate-180' : ''}`} />
              </button>

              {showFallback && (
                <div className="mt-2 p-2.5 rounded bg-slate-900 border border-slate-800 text-xs text-amber-200/90 leading-relaxed font-sans">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 block mb-1">
                    Compromise Position:
                  </span>
                  {activeClause.suggestedRedline.fallbackPosition}
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="pt-2 flex items-center gap-2">
              {activeClause.suggestedRedline.accepted ? (
                <div className="w-full py-2 rounded bg-emerald-950 border border-emerald-700 text-emerald-300 text-xs font-bold text-center flex items-center justify-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" /> Redline Applied to Active Draft
                </div>
              ) : (
                <button
                  onClick={() => onAcceptRedline(activeClause.id)}
                  className="w-full py-2 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors cursor-pointer shadow-md flex items-center justify-center gap-1.5"
                >
                  <Check className="w-4 h-4" /> Accept & Apply Redline
                </button>
              )}
            </div>
          </div>

          {/* Precedent Matches in Past Executed Matters */}
          <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-200">
                <BookOpen className="w-4 h-4 text-indigo-400" />
                <span>Precedents from Executed Matters ({matchingPrecedents.length})</span>
              </div>
              <button
                onClick={onOpenPrecedentsModal}
                className="text-[11px] text-indigo-400 hover:text-indigo-300 underline font-medium cursor-pointer"
              >
                Open Full Library
              </button>
            </div>

            {matchingPrecedents.length > 0 ? (
              <div className="space-y-2">
                {matchingPrecedents.map((prec) => (
                  <div
                    key={prec.id}
                    onClick={() => onOpenPrecedentDetail(prec)}
                    className="p-2.5 rounded bg-slate-900 border border-slate-800 hover:border-slate-700 hover:bg-slate-800/80 transition-all cursor-pointer group"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-semibold text-white group-hover:text-indigo-300">
                        {prec.counterparty}
                      </span>
                      <span className="px-1.5 py-0.2 rounded bg-indigo-950 text-indigo-300 border border-indigo-800 text-[10px] font-bold font-mono">
                        {prec.similarityScore}% Match
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                      {prec.concessionNotes}
                    </p>
                    <div className="mt-1.5 flex items-center justify-between text-[10px] text-slate-500">
                      <span>{prec.governingLaw} Law • {prec.leadCounselName}</span>
                      <span className="text-indigo-400 group-hover:underline">Compare →</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-500 italic py-2">
                No direct category match found in recent executed agreements. Click "Open Full Library" to browse all precedents.
              </p>
            )}
          </div>
        </div>
      ) : (
        <div className="p-8 text-center text-slate-500 text-xs">
          Select a flagged clause from the contract or list above to inspect legal risk and redline recommendations.
        </div>
      )}
    </div>
  );
};
