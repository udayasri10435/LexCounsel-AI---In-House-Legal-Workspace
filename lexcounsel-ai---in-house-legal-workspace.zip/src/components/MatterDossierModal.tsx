import React from 'react';
import { FolderLock, X, Calendar, User, Building2, ShieldCheck, Database, FileText, CheckCircle2, Clock } from 'lucide-react';
import { Matter } from '../types/legal';

interface MatterDossierModalProps {
  isOpen: boolean;
  onClose: () => void;
  matter: Matter;
  onOpenDmsModal: () => void;
}

export const MatterDossierModal: React.FC<MatterDossierModalProps> = ({
  isOpen,
  onClose,
  matter,
  onOpenDmsModal,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-2xl rounded-xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center">
              <FolderLock className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-indigo-400">{matter.matterNumber}</span>
                <span className="text-slate-600">•</span>
                <span className="text-xs text-slate-300 font-medium">{matter.practiceArea}</span>
              </div>
              <h2 className="font-bold text-base text-white">{matter.title}</h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 text-xs">
          {/* Status & Risk Tolerance */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
              <span className="text-slate-500 text-[10px] uppercase font-bold block mb-1">Matter Status</span>
              <span className="font-bold text-amber-400 text-xs">{matter.status}</span>
            </div>
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
              <span className="text-slate-500 text-[10px] uppercase font-bold block mb-1">Risk Tolerance</span>
              <span className="font-bold text-slate-200 text-xs">{matter.riskTolerance}</span>
            </div>
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
              <span className="text-slate-500 text-[10px] uppercase font-bold block mb-1">Privilege Level</span>
              <span className="font-bold text-emerald-400 text-[11px] uppercase tracking-wider block truncate">
                {matter.privilegeLevel.split(' ')[0]}
              </span>
            </div>
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
              <span className="text-slate-500 text-[10px] uppercase font-bold block mb-1">Target Close</span>
              <span className="font-bold text-slate-200 text-xs">{matter.targetClosingDate}</span>
            </div>
          </div>

          {/* Stakeholders & Counterparty */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
            <h3 className="font-bold text-slate-200 uppercase tracking-wider text-[11px]">
              Matter Stakeholders & Counterparty
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <span className="text-slate-500 text-[10px] uppercase block">Lead In-House Counsel:</span>
                <span className="font-semibold text-white">{matter.leadCounsel}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] uppercase block">Counterparty Entity:</span>
                <span className="font-semibold text-white">{matter.counterparty}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] uppercase block">Client Business Unit:</span>
                <span className="font-semibold text-white">{matter.clientBusinessUnit}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] uppercase block">Business Owner / Sponsor:</span>
                <span className="font-semibold text-white">{matter.businessOwner}</span>
              </div>
            </div>
          </div>

          {/* Linked DMS Workspace */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-sky-950 border border-sky-800 flex items-center justify-center">
                <Database className="w-4 h-4 text-sky-400" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white text-xs">{matter.dms.provider} Workspace</span>
                  <span className="font-mono text-sky-400 font-semibold">{matter.dms.documentNumber}</span>
                </div>
                <p className="text-[11px] text-slate-400">{matter.dms.workspaceName}</p>
              </div>
            </div>

            <button
              onClick={() => {
                onClose();
                onOpenDmsModal();
              }}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold cursor-pointer"
            >
              Manage Sync →
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs cursor-pointer shadow-md"
          >
            Close Dossier
          </button>
        </div>
      </div>
    </div>
  );
};
