import React, { useState } from 'react';
import { 
  Database, 
  X, 
  Check, 
  Lock, 
  Unlock, 
  RefreshCw, 
  UploadCloud, 
  FileText, 
  Clock, 
  CheckCircle2, 
  Building2, 
  FolderLock,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import { Matter, DmsType, DmsMetadata } from '../types/legal';
import { syncDmsAPI } from '../services/geminiLegalService';

interface DmsIntegrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  matter: Matter;
  onUpdateDms: (updatedDms: DmsMetadata) => void;
}

export const DmsIntegrationModal: React.FC<DmsIntegrationModalProps> = ({
  isOpen,
  onClose,
  matter,
  onUpdateDms,
}) => {
  const [selectedProvider, setSelectedProvider] = useState<DmsType>(matter.dms.provider);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatusMessage, setSyncStatusMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleAction = async (action: 'sync' | 'checkout' | 'save_new_version') => {
    setIsSyncing(true);
    setSyncStatusMessage(null);

    try {
      const result = await syncDmsAPI(
        selectedProvider,
        matter.dms.workspaceId,
        matter.dms.documentNumber,
        matter.dms.version,
        action
      );

      const updatedDms: DmsMetadata = {
        ...matter.dms,
        provider: selectedProvider,
        documentNumber: result.documentNumber,
        version: result.version,
        isCheckedOut: action === 'checkout' ? true : action === 'sync' ? matter.dms.isCheckedOut : false,
        checkedOutBy: action === 'checkout' ? 'Eleanor Vance (GC Office)' : undefined,
        lastSyncedAt: result.lastSyncedAt,
      };

      onUpdateDms(updatedDms);
      setSyncStatusMessage(result.message);
    } catch (err: any) {
      setSyncStatusMessage(`Sync error: ${err.message}`);
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-2xl rounded-xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-sky-600/20 border border-sky-500/40 flex items-center justify-center">
              <Database className="w-5 h-5 text-sky-400" />
            </div>
            <div>
              <h2 className="font-bold text-base text-white">DMS Integration Console</h2>
              <p className="text-xs text-slate-400">
                Direct Matter & Workspace Sync with iManage Work 10 and NetDocuments
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* DMS Provider Switcher */}
          <div>
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block mb-2">
              Select Enterprise Document Management System:
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setSelectedProvider('iManage')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                  selectedProvider === 'iManage'
                    ? 'bg-sky-950/60 border-sky-500 shadow-md ring-1 ring-sky-500 text-white'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-sm">iManage Work 10</span>
                  {selectedProvider === 'iManage' && <Check className="w-4 h-4 text-sky-400" />}
                </div>
                <p className="text-xs text-slate-400">
                  Universal API v2 • Workspace & Matter dossier binding
                </p>
              </button>

              <button
                type="button"
                onClick={() => setSelectedProvider('NetDocuments')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                  selectedProvider === 'NetDocuments'
                    ? 'bg-indigo-950/60 border-indigo-500 shadow-md ring-1 ring-indigo-500 text-white'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-sm">NetDocuments</span>
                  {selectedProvider === 'NetDocuments' && <Check className="w-4 h-4 text-indigo-400" />}
                </div>
                <p className="text-xs text-slate-400">
                  REST API & ndOffice Cabinet profiling sync
                </p>
              </button>
            </div>
          </div>

          {/* Active Workspace Dossier */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800/80">
              <div className="flex items-center gap-2">
                <FolderLock className="w-4 h-4 text-indigo-400" />
                <span className="font-bold text-white uppercase tracking-wider">
                  DMS Linked Metadata
                </span>
              </div>
              <span className="text-[11px] text-slate-400">
                Last Synced: <strong className="text-slate-300">{matter.dms.lastSyncedAt}</strong>
              </span>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <span className="text-slate-500 block text-[10px] uppercase">Cabinet / Database:</span>
                <span className="font-mono text-slate-200">{matter.dms.cabinetOrDatabase}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px] uppercase">Workspace ID:</span>
                <span className="font-mono text-slate-200">{matter.dms.workspaceId}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px] uppercase">Workspace Folder:</span>
                <span className="text-slate-200 font-medium truncate block">{matter.dms.workspaceName}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px] uppercase">Document Record:</span>
                <span className="font-mono text-sky-400 font-bold">{matter.dms.documentNumber} (v{matter.dms.version}.0)</span>
              </div>
            </div>

            {/* Check-out lock status */}
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
              <div className="flex items-center gap-2">
                {matter.dms.isCheckedOut ? (
                  <>
                    <Lock className="w-3.5 h-3.5 text-amber-400" />
                    <span className="text-amber-300 font-medium">Checked Out (Locked for In-House Redlining)</span>
                  </>
                ) : (
                  <>
                    <Unlock className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-300 font-medium">Checked In (Available in DMS)</span>
                  </>
                )}
              </div>
              {matter.dms.checkedOutBy && (
                <span className="text-slate-400 text-[11px]">By: {matter.dms.checkedOutBy}</span>
              )}
            </div>
          </div>

          {/* Sync status feedback */}
          {syncStatusMessage && (
            <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-800 text-xs text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{syncStatusMessage}</span>
            </div>
          )}

          {/* Action Buttons */}
          <div className="space-y-2 pt-2">
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                disabled={isSyncing}
                onClick={() => handleAction('checkout')}
                className="p-3 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-slate-200 flex items-center justify-center gap-2 transition-colors cursor-pointer disabled:opacity-50"
              >
                <Lock className="w-4 h-4 text-amber-400" />
                <span>Check Out to In-House Vault</span>
              </button>

              <button
                type="button"
                disabled={isSyncing}
                onClick={() => handleAction('sync')}
                className="p-3 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-slate-200 flex items-center justify-center gap-2 transition-colors cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 text-sky-400 ${isSyncing ? 'animate-spin' : ''}`} />
                <span>Fetch Latest from DMS</span>
              </button>
            </div>

            <button
              type="button"
              disabled={isSyncing}
              onClick={() => handleAction('save_new_version')}
              className="w-full py-3 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-lg disabled:opacity-50"
            >
              <UploadCloud className="w-4 h-4" />
              <span>Save In-House Redline Back to {selectedProvider} as Version {matter.dms.version + 1}.0</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-1.5 text-slate-400">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>End-to-End DMS OAuth & TLS 1.3 Certified Connection</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
