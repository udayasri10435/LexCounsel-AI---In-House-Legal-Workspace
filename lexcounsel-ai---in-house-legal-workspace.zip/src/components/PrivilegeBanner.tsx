import React from 'react';
import { ShieldCheck, Lock, EyeOff, FileText, CheckCircle2, AlertCircle } from 'lucide-react';
import { Matter } from '../types/legal';

interface PrivilegeBannerProps {
  matter: Matter;
  isRedactionActive: boolean;
  onOpenPrivilegeModal: () => void;
  onOpenRedactionModal: () => void;
}

export const PrivilegeBanner: React.FC<PrivilegeBannerProps> = ({
  matter,
  isRedactionActive,
  onOpenPrivilegeModal,
  onOpenRedactionModal,
}) => {
  return (
    <div className="bg-gradient-to-r from-slate-900 via-indigo-950/60 to-slate-900 border-b border-indigo-900/40 px-4 py-2 flex flex-wrap items-center justify-between gap-3 text-xs shadow-inner">
      <div className="flex items-center gap-2.5">
        <div className="w-5 h-5 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
          <Lock className="w-3 h-3 text-amber-400" />
        </div>
        <div>
          <span className="font-semibold text-slate-200 uppercase tracking-wider">
            {matter.privilegeLevel}
          </span>
          <span className="text-slate-400 ml-2 hidden sm:inline">
            • Confidential legal communication prepared for evaluation of corporate legal exposure.
          </span>
        </div>
      </div>

      <div className="flex items-center gap-4">
        {/* Privacy Perimeter Guarantee */}
        <div className="flex items-center gap-1.5 text-slate-300">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-[11px]">
            Zero Data Retention Policy: <strong className="text-emerald-300">Enforced</strong>
          </span>
        </div>

        {/* Client-Side Sanitizer Badge */}
        <button
          onClick={onOpenRedactionModal}
          className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-slate-800/80 border border-slate-700 hover:border-slate-600 text-slate-300 hover:text-white transition-colors cursor-pointer"
        >
          <EyeOff className="w-3 h-3 text-sky-400" />
          <span className="text-[11px]">
            {isRedactionActive ? (
              <span className="text-emerald-400 font-medium">PII & Financials Masked (8 rules)</span>
            ) : (
              <span className="text-amber-400 font-medium">Unmasked Mode</span>
            )}
          </span>
        </button>

        {/* Privilege Log Quick Link */}
        <button
          onClick={onOpenPrivilegeModal}
          className="flex items-center gap-1 text-[11px] text-indigo-400 hover:text-indigo-300 font-medium underline cursor-pointer"
        >
          <FileText className="w-3 h-3" />
          <span>Privilege Ledger</span>
        </button>
      </div>
    </div>
  );
};
