import React, { useState } from 'react';
import { 
  Scale, 
  ShieldCheck, 
  Database, 
  Search, 
  FolderLock, 
  FileText, 
  Sparkles, 
  ChevronDown, 
  EyeOff, 
  Download, 
  RefreshCw,
  Plus,
  BookOpen
} from 'lucide-react';
import { Matter, DmsMetadata } from '../types/legal';

interface HeaderProps {
  matters: Matter[];
  activeMatter: Matter;
  onSelectMatter: (matter: Matter) => void;
  onOpenDmsModal: () => void;
  onOpenPrecedentsModal: () => void;
  onOpenPrivilegeModal: () => void;
  onOpenRedactionModal: () => void;
  onOpenExecutiveSummary: () => void;
  onOpenMatterDossier: () => void;
  onOpenNewMatterModal: () => void;
  onToggleCopilot: () => void;
  isCopilotOpen: boolean;
  isRedactionActive: boolean;
  onToggleRedaction: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  matters,
  activeMatter,
  onSelectMatter,
  onOpenDmsModal,
  onOpenPrecedentsModal,
  onOpenPrivilegeModal,
  onOpenRedactionModal,
  onOpenExecutiveSummary,
  onOpenMatterDossier,
  onOpenNewMatterModal,
  onToggleCopilot,
  isCopilotOpen,
  isRedactionActive,
  onToggleRedaction,
}) => {
  const [matterDropdownOpen, setMatterDropdownOpen] = useState(false);

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 sticky top-0 z-30 shadow-md">
      {/* Top Privilege & Classification Bar */}
      <div className="bg-slate-950 px-4 py-1 border-b border-slate-800/80 flex items-center justify-between text-xs">
        <div className="flex items-center gap-3">
          <button 
            onClick={onOpenPrivilegeModal}
            className="flex items-center gap-1.5 text-amber-400 hover:text-amber-300 font-semibold tracking-wider transition-colors cursor-pointer"
            title="Click to view Privilege Log & Legal Disclaimers"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>ATTORNEY-CLIENT PRIVILEGED & ATTORNEY WORK PRODUCT</span>
          </button>
          <span className="text-slate-600">|</span>
          <span className="text-slate-400">Matter: <strong className="text-slate-200">{activeMatter.matterNumber}</strong></span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-400">Classification: <span className="text-emerald-400 font-mono">CONFIDENTIAL // IN-HOUSE ONLY</span></span>
        </div>

        <div className="flex items-center gap-3">
          {/* Privilege-Safe Redaction Shield Switch */}
          <button
            onClick={onToggleRedaction}
            className={`flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-medium border transition-colors cursor-pointer ${
              isRedactionActive 
                ? 'bg-emerald-950/70 border-emerald-500/50 text-emerald-300 hover:bg-emerald-900/60' 
                : 'bg-amber-950/70 border-amber-500/50 text-amber-300 hover:bg-amber-900/60'
            }`}
            title="Client-Side Redaction: Masks internal PII, executive names, and financial figures before analysis"
          >
            <EyeOff className="w-3 h-3" />
            <span>Privilege Shield: {isRedactionActive ? 'ON (Data Sanitized)' : 'OFF (Raw Text)'}</span>
          </button>

          <button 
            onClick={onOpenRedactionModal}
            className="text-[11px] text-slate-400 hover:text-slate-200 underline cursor-pointer"
          >
            Inspect Masking
          </button>

          {/* DMS Connection Quick Pill */}
          <button
            onClick={onOpenDmsModal}
            className="flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-medium bg-slate-800/80 border border-slate-700 text-sky-300 hover:bg-slate-700/70 transition-colors cursor-pointer"
            title="Open Document Management System Integration (iManage / NetDocs)"
          >
            <Database className="w-3 h-3 text-sky-400" />
            <span>{activeMatter.dms.provider}: <strong className="text-white">{activeMatter.dms.documentNumber}</strong></span>
            {activeMatter.dms.isCheckedOut && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" title="Document Checked Out" />
            )}
          </button>
        </div>
      </div>

      {/* Main App Navigation */}
      <div className="px-4 py-2.5 flex items-center justify-between gap-4">
        {/* Brand & Matter Context */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-indigo-600 via-indigo-700 to-sky-600 flex items-center justify-center shadow-inner border border-indigo-400/30">
              <Scale className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="font-bold text-base text-white tracking-tight leading-none">LexCounsel AI</h1>
                <span className="px-1.5 py-0.2 text-[10px] uppercase font-bold tracking-wider rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  In-House GC
                </span>
              </div>
              <p className="text-[11px] text-slate-400 leading-tight">Contract Review, Risk Flagging & Precedent Search</p>
            </div>
          </div>

          <div className="h-6 w-px bg-slate-800" />

          {/* Matter Selector Dropdown */}
          <div className="relative">
            <button
              onClick={() => setMatterDropdownOpen(!matterDropdownOpen)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-slate-800/90 hover:bg-slate-800 border border-slate-700 text-left transition-all cursor-pointer group"
            >
              <FolderLock className="w-4 h-4 text-indigo-400" />
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-white group-hover:text-indigo-200">
                    {activeMatter.matterNumber}
                  </span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-700 text-slate-300 font-medium">
                    {activeMatter.practiceArea}
                  </span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded font-medium ${
                    activeMatter.status === 'Redlining' ? 'bg-amber-900/60 text-amber-200 border border-amber-700/50' :
                    activeMatter.status === 'In Review' ? 'bg-sky-900/60 text-sky-200 border border-sky-700/50' :
                    'bg-emerald-900/60 text-emerald-200 border border-emerald-700/50'
                  }`}>
                    {activeMatter.status}
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 truncate max-w-[280px]">
                  {activeMatter.title}
                </div>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 group-hover:text-slate-200 ml-1" />
            </button>

            {/* Matter Switcher Menu */}
            {matterDropdownOpen && (
              <div className="absolute left-0 mt-1.5 w-96 rounded-lg bg-slate-900 border border-slate-700 shadow-2xl py-2 z-50 animate-in fade-in zoom-in-95">
                <div className="px-3 pb-2 border-b border-slate-800 flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Active Legal Matters</span>
                  <button
                    onClick={() => {
                      setMatterDropdownOpen(false);
                      onOpenNewMatterModal();
                    }}
                    className="flex items-center gap-1 text-xs text-indigo-400 hover:text-indigo-300 font-medium cursor-pointer"
                  >
                    <Plus className="w-3 h-3" /> New Matter
                  </button>
                </div>
                <div className="max-h-72 overflow-y-auto divide-y divide-slate-800/50">
                  {matters.map((m) => (
                    <button
                      key={m.id}
                      onClick={() => {
                        onSelectMatter(m);
                        setMatterDropdownOpen(false);
                      }}
                      className={`w-full text-left p-3 hover:bg-slate-800/80 transition-colors flex items-start gap-2.5 cursor-pointer ${
                        m.id === activeMatter.id ? 'bg-slate-800/90 border-l-2 border-indigo-500' : ''
                      }`}
                    >
                      <FolderLock className={`w-4 h-4 mt-0.5 ${m.id === activeMatter.id ? 'text-indigo-400' : 'text-slate-500'}`} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-semibold text-white">{m.matterNumber}</span>
                          <span className="text-[10px] text-slate-400">{m.practiceArea}</span>
                        </div>
                        <p className="text-xs text-slate-300 truncate font-medium">{m.title}</p>
                        <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400">
                          <span>{m.counterparty}</span>
                          <span>•</span>
                          <span className="text-sky-400 font-mono text-[10px]">{m.dms.provider} {m.dms.documentNumber}</span>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
                <div className="p-2 border-t border-slate-800 bg-slate-950/50">
                  <button
                    onClick={() => {
                      setMatterDropdownOpen(false);
                      onOpenMatterDossier();
                    }}
                    className="w-full text-center text-xs text-indigo-300 hover:text-indigo-200 py-1 font-medium cursor-pointer"
                  >
                    View Full Matter Dossier & Audit Log →
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Global Legal Actions */}
        <div className="flex items-center gap-2">
          {/* Precedent Search Library */}
          <button
            onClick={onOpenPrecedentsModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-slate-800 hover:bg-slate-700/80 border border-slate-700 text-xs font-medium text-slate-200 hover:text-white transition-colors cursor-pointer shadow-sm"
            title="Search precedent clauses from executed past company deals (Snowflake, AWS, Salesforce, etc.)"
          >
            <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
            <span>Precedent Bank</span>
          </button>

          {/* DMS Connector */}
          <button
            onClick={onOpenDmsModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-slate-800 hover:bg-slate-700/80 border border-slate-700 text-xs font-medium text-slate-200 hover:text-white transition-colors cursor-pointer shadow-sm"
            title="iManage Work 10 & NetDocuments integration manager"
          >
            <Database className="w-3.5 h-3.5 text-sky-400" />
            <span>DMS Sync</span>
          </button>

          {/* Executive Risk Briefing for CFO/GC */}
          <button
            onClick={onOpenExecutiveSummary}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-slate-800 hover:bg-slate-700/80 border border-slate-700 text-xs font-medium text-slate-200 hover:text-white transition-colors cursor-pointer shadow-sm"
            title="Generate executive 1-page risk memo for CFO and signing officers"
          >
            <FileText className="w-3.5 h-3.5 text-amber-400" />
            <span>CFO Risk Memo</span>
          </button>

          {/* Counsel Copilot Toggle */}
          <button
            onClick={onToggleCopilot}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer shadow-sm ${
              isCopilotOpen
                ? 'bg-indigo-600 text-white shadow-indigo-600/30 shadow-lg ring-1 ring-indigo-400'
                : 'bg-indigo-950 text-indigo-300 hover:bg-indigo-900 border border-indigo-700/50'
            }`}
            title="Toggle Gemini 3.8 Flash In-House Counsel Copilot"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-300" />
            <span>Counsel Copilot</span>
          </button>
        </div>
      </div>
    </header>
  );
};
