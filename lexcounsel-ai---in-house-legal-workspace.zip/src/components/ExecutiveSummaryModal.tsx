import React, { useState } from 'react';
import { FileText, X, Printer, Copy, Check, Download, AlertTriangle, Scale, ShieldAlert } from 'lucide-react';
import { Matter, LegalContract } from '../types/legal';

interface ExecutiveSummaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  matter: Matter;
  contract: LegalContract;
}

export const ExecutiveSummaryModal: React.FC<ExecutiveSummaryModalProps> = ({
  isOpen,
  onClose,
  matter,
  contract,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    const memoText = `MEMORANDUM - ATTORNEY-CLIENT PRIVILEGED // ATTORNEY WORK PRODUCT
TO: Chief Financial Officer, General Counsel, VP Operations
FROM: ${matter.leadCounsel}
DATE: ${new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
MATTER: ${matter.matterNumber} - ${matter.title}
COUNTERPARTY: ${matter.counterparty}
OVERALL RISK SCORE: ${contract.overallRiskScore}/100 (ELEVATED RISK)

1. EXECUTIVE SUMMARY & SIGNING RECOMMENDATION:
The Legal Department strongly advises AGAINST executing the proposed vendor agreement in its present form. The contract introduces catastrophic asymmetrical liability and broad AI model training rights on proprietary enterprise telemetry.

2. TOP CONTRACTUAL DEAL-BREAKERS:
- Section 7.2 & 5.2 (Limitation of Liability & IP Indemnity): Vendor caps its total damages to 12 months fees, and caps patent infringement defense to only 3 months of fees ($37,500). Meanwhile, Customer indemnification under Section 5.1 is completely uncapped.
- Section 3.2 (AI Model Training): Vendor claims perpetual, irrevocable license to ingest and train its proprietary AI/ML models on customer data and telemetry.
- Section 2.2 (Fee Escalation): Compounding 15% annual fee increases on minimal 30-day notice.

3. FINANCIAL EXPOSURE ASSESSMENT:
Estimated unhedged balance sheet exposure exceeds $15,000,000 in third-party patent litigation and trade secret leakage.

4. NEXT STEPS:
We have prepared and issued the In-House Counter-Proposal Redline. A counsel-to-counsel negotiation call is scheduled. Executive sign-off should be withheld until mutual 2x ARR cap and deletion of Section 3.2 are secured.`;

    navigator.clipboard.writeText(memoText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-3xl rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center">
              <FileText className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h2 className="font-bold text-base text-white">Executive Risk Memorandum for CFO & GC</h2>
              <p className="text-xs text-slate-400">
                Formal legal briefing for C-suite executive sign-off and risk allocation
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Legal Memo Body */}
        <div className="flex-1 overflow-y-auto p-6 md:p-8 bg-slate-950 font-serif text-slate-200 space-y-6">
          {/* Privilege Classification Banner */}
          <div className="border-b-2 border-slate-700 pb-4 text-center">
            <span className="text-xs font-mono font-bold tracking-widest text-amber-400 uppercase">
              CONFIDENTIAL // ATTORNEY-CLIENT PRIVILEGED // WORK PRODUCT DOCTRINE
            </span>
            <h1 className="text-xl font-bold font-sans text-white mt-1">
              LEGAL RISK EVALUATION & ADVISORY MEMORANDUM
            </h1>
          </div>

          {/* Memo Metadata Block */}
          <div className="grid grid-cols-2 gap-2 text-xs font-sans border-b border-slate-800 pb-4">
            <div>
              <span className="text-slate-500 font-semibold">TO:</span> Chief Financial Officer, General Counsel, EVP Operations
            </div>
            <div>
              <span className="text-slate-500 font-semibold">DATE:</span> {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
            </div>
            <div>
              <span className="text-slate-500 font-semibold">FROM:</span> {matter.leadCounsel}
            </div>
            <div>
              <span className="text-slate-500 font-semibold">MATTER:</span> {matter.matterNumber} ({matter.practiceArea})
            </div>
            <div className="col-span-2">
              <span className="text-slate-500 font-semibold">SUBJECT:</span> Contract Review & Risk Assessment — {matter.title}
            </div>
          </div>

          {/* Risk Metric Box */}
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 font-sans flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
                Executive Risk Score
              </span>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-2xl font-bold text-rose-400 font-mono">
                  {contract.overallRiskScore} / 100
                </span>
                <span className="text-xs px-2 py-0.5 rounded font-bold bg-rose-950 text-rose-300 border border-rose-800">
                  HIGH CONTRACTUAL RISK
                </span>
              </div>
            </div>

            <div className="text-right">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
                Legal Recommendation
              </span>
              <span className="text-sm font-bold text-rose-400">
                WITHHOLD SIGNATURE (Pending Redline)
              </span>
            </div>
          </div>

          {/* Section 1: Executive Summary */}
          <div className="space-y-2">
            <h3 className="font-bold font-sans text-sm text-white uppercase tracking-wider border-b border-slate-800 pb-1">
              1. Executive Summary & Legal Exposure
            </h3>
            <p className="text-xs leading-relaxed text-slate-300">
              The Legal Department has completed its thorough review of the proposed contract submitted by <strong className="text-white">{matter.counterparty}</strong>. 
              The draft contains three severe deviations from company board-approved risk standards. Most egregiously, the vendor restricts its defense obligations for intellectual property infringement to 3 months of fees ($37,500), while exposing our enterprise to uncapped indemnity liabilities. Furthermore, the vendor claims perpetual rights to vectorize enterprise telemetry into its commercial machine learning heuristics.
            </p>
          </div>

          {/* Section 2: Top Contractual Deal Breakers */}
          <div className="space-y-3">
            <h3 className="font-bold font-sans text-sm text-white uppercase tracking-wider border-b border-slate-800 pb-1">
              2. Critical Deal-Breaker Provisions
            </h3>

            <div className="space-y-2.5 text-xs font-sans">
              <div className="p-3 rounded-lg bg-rose-950/20 border border-rose-900/40 space-y-1">
                <div className="flex items-center justify-between text-rose-300 font-bold">
                  <span>A. Asymmetrical Liability & Sub-Capped Patent Indemnity (Section 7 & 5.2)</span>
                  <span className="font-mono text-rose-400">HIGH EXPOSURE</span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Vendor caps its total damages to 12 months fees and sub-caps patent indemnity to only 3 months ($37,500), but leaves Customer indemnity completely uncapped. In the event of a cloud patent lawsuit, our company would bear nearly 100% of defense costs.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-rose-950/20 border border-rose-900/40 space-y-1">
                <div className="flex items-center justify-between text-rose-300 font-bold">
                  <span>B. Vendor Commercial AI Model Ingestion (Section 3.2)</span>
                  <span className="font-mono text-rose-400">HIGH EXPOSURE</span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Grants vendor perpetual, irrevocable rights to ingest and train internal AI/ML models on customer infrastructure logs, risking trade secret leakage and data contamination.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-amber-950/20 border border-amber-900/40 space-y-1">
                <div className="flex items-center justify-between text-amber-300 font-bold">
                  <span>C. Compounding 15% Annual Fee Escalations (Section 2.2)</span>
                  <span className="font-mono text-amber-400">MEDIUM EXPOSURE</span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Allows vendor to increase annual fees by 15% on each renewal with only 30 days notice. Over a 3-year term, this adds over $150,000 in unbudgeted procurement costs.
                </p>
              </div>
            </div>
          </div>

          {/* Section 3: Recommended Action Plan */}
          <div className="space-y-2">
            <h3 className="font-bold font-sans text-sm text-white uppercase tracking-wider border-b border-slate-800 pb-1">
              3. Recommended In-House Action Plan
            </h3>
            <p className="text-xs leading-relaxed text-slate-300">
              1. Issue our primary In-House Redline restoring a mutual 2x ARR cap, a $5,000,000 super-cap for IP/Data Breaches, and deleting Section 3.2 AI model training in its entirety.
              <br />
              2. Instruct VP of Infrastructure to hold technical deployment until vendor executes the redlined version or our secondary fallback compromise.
            </p>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs">
          <div className="text-slate-400 text-[11px]">
            Saved to iManage: <strong className="text-white font-mono">{matter.dms.documentNumber}</strong>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied Memo' : 'Copy Text'}</span>
            </button>
            <button
              onClick={handlePrint}
              className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-md"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Memo</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
