import React, { useState, useRef, useEffect } from 'react';
import { 
  Sparkles, 
  Send, 
  Bot, 
  User, 
  Copy, 
  Check, 
  X, 
  RotateCcw, 
  FileText, 
  Mail, 
  ShieldAlert, 
  Lightbulb,
  Maximize2,
  Minimize2
} from 'lucide-react';
import { Matter, LegalContract } from '../types/legal';
import { askCounselCopilotAPI } from '../services/geminiLegalService';

interface CounselCopilotProps {
  isOpen: boolean;
  onClose: () => void;
  matter: Matter;
  contract: LegalContract;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

const QUICK_PROMPTS = [
  {
    icon: Mail,
    label: 'Negotiation Email to Vendor Counsel',
    prompt: 'Draft a polite but firm 3-bullet negotiation email to vendor counsel explaining our primary objections to Section 7 (Liability) and Section 3.2 (AI training).'
  },
  {
    icon: ShieldAlert,
    label: 'Identify Uncapped Liabilities',
    prompt: 'Analyze this contract and identify every provision where our company faces uncapped or asymmetrical financial exposure.'
  },
  {
    icon: FileText,
    label: 'Executive Briefing for CFO',
    prompt: 'Prepare a 1-page Executive Legal Risk Memo for our CFO summarizing whether this contract is safe to sign in its current form.'
  },
  {
    icon: Lightbulb,
    label: 'AI Model Training Risk Analysis',
    prompt: 'Explain the technical and trade secret risks of Section 3.2 where the vendor claims the right to train AI heuristics on our customer telemetry.'
  }
];

export const CounselCopilot: React.FC<CounselCopilotProps> = ({
  isOpen,
  onClose,
  matter,
  contract,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      content: `### Welcome to In-House Counsel Copilot

I am your privilege-aware Legal Copilot analyzing **${matter.matterNumber}: ${matter.title}**.

I can assist you with:
- **Redline Rationale & Counter-Proposals** aligned with corporate playbook rules
- **Negotiation emails** to vendor counsel with deal-closing language
- **Exposure quantification** on indemnity and liability sub-caps
- **Executive Risk Briefings** for the CFO & General Counsel

How can I assist your review of this agreement today?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  if (!isOpen) return null;

  const handleSend = async (queryToSend?: string) => {
    const text = queryToSend || inputQuery;
    if (!text.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputQuery('');
    setIsLoading(true);

    try {
      const response = await askCounselCopilotAPI(
        text,
        contract.content,
        matter
      );

      const assistantMsg: ChatMessage = {
        id: `assistant-${Date.now()}`,
        sender: 'assistant',
        content: response,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (error: any) {
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        sender: 'assistant',
        content: `**Notice**: Unable to reach legal analysis service. ${error.message}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="fixed inset-y-0 right-0 z-40 w-full sm:w-[480px] md:w-[540px] bg-slate-900 border-l border-slate-700 shadow-2xl flex flex-col animate-in slide-in-from-right duration-300">
      {/* Copilot Header */}
      <div className="p-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-indigo-400" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="font-bold text-sm text-white">Counsel Copilot</h3>
              <span className="px-1.5 py-0.2 rounded text-[9px] font-mono uppercase bg-emerald-950 text-emerald-300 border border-emerald-800">
                Gemini 3.8 Flash
              </span>
            </div>
            <p className="text-[11px] text-slate-400">Privilege-Safe Legal Counsel Assistant</p>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => setMessages([messages[0]])}
            className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
            title="Clear Chat History"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <button
            onClick={onClose}
            className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
            title="Close Copilot"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Quick Prompts Carousel */}
      <div className="bg-slate-950/80 px-3 py-2 border-b border-slate-800 flex gap-1.5 overflow-x-auto text-[11px]">
        {QUICK_PROMPTS.map((qp, idx) => {
          const Icon = qp.icon;
          return (
            <button
              key={idx}
              onClick={() => handleSend(qp.prompt)}
              className="px-2.5 py-1 rounded-full bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-slate-300 hover:text-white whitespace-nowrap flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
            >
              <Icon className="w-3 h-3 text-indigo-400" />
              <span>{qp.label}</span>
            </button>
          );
        })}
      </div>

      {/* Chat Messages Log */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs font-sans">
        {messages.map((msg) => {
          const isUser = msg.sender === 'user';
          return (
            <div
              key={msg.id}
              className={`flex items-start gap-2.5 ${isUser ? 'flex-row-reverse' : ''}`}
            >
              <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
                isUser 
                  ? 'bg-indigo-600 text-white' 
                  : 'bg-slate-800 border border-slate-700 text-indigo-400'
              }`}>
                {isUser ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
              </div>

              <div className={`max-w-[85%] rounded-lg p-3 relative group ${
                isUser 
                  ? 'bg-indigo-600 text-white rounded-tr-none' 
                  : 'bg-slate-950 border border-slate-800 text-slate-200 rounded-tl-none shadow-sm'
              }`}>
                {/* Copy Button */}
                <button
                  onClick={() => handleCopy(msg.id, msg.content)}
                  className="absolute right-2 top-2 p-1 rounded bg-slate-900/60 hover:bg-slate-800 text-slate-400 hover:text-slate-200 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                  title="Copy message"
                >
                  {copiedId === msg.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                </button>

                <div className="prose prose-invert prose-xs max-w-none space-y-2 whitespace-pre-wrap leading-relaxed">
                  {msg.content}
                </div>

                <div className={`mt-1.5 text-[10px] ${isUser ? 'text-indigo-200' : 'text-slate-500'}`}>
                  {msg.timestamp}
                </div>
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-center gap-2.5 text-slate-400 text-xs">
            <div className="w-7 h-7 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-indigo-400 animate-pulse">
              <Bot className="w-3.5 h-3.5" />
            </div>
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-indigo-400 animate-ping" />
              <span>Analyzing contract terms & precedent benchmarks...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Box */}
      <div className="p-3 bg-slate-950 border-t border-slate-800">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            placeholder="Ask Counsel Copilot (e.g. 'Draft counter-language for Section 5')..."
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            disabled={isLoading}
            className="flex-1 bg-slate-900 text-slate-200 placeholder-slate-500 px-3.5 py-2.5 rounded-lg text-xs border border-slate-700 focus:outline-none focus:border-indigo-500 transition-all disabled:opacity-50"
          />
          <button
            type="submit"
            disabled={!inputQuery.trim() || isLoading}
            className="p-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white disabled:opacity-40 disabled:hover:bg-indigo-600 transition-colors cursor-pointer shadow-md"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
        <div className="mt-1.5 flex items-center justify-between text-[10px] text-slate-500 px-1">
          <span>Attorney-Client Privilege Preserved</span>
          <span>Zero Retention Policy</span>
        </div>
      </div>
    </div>
  );
};
