import React, { useState } from 'react';
import { ShieldCheck, X, Download, FileText, Lock, CheckCircle2, ArrowRight } from 'lucide-react';
import { Matter, PrivilegeLogEntry } from '../types/legal';

interface PrivilegeLogModalProps {
  isOpen: boolean;
  onClose: () => void;
  matter: Matter;
}

export const PrivilegeLogModal: React.FC<PrivilegeLogModalProps> = ({
  isOpen,
  onClose,
  matter,
}) => {
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  if (!isOpen) return null;

  const sampleLogEntries: PrivilegeLogEntry[] = [
    {
      id: 'PL-001',
      timestamp: '2026-03-28 14:15 EST',
      matterNumber: matter.matterNumber,
      documentTitle: `${matter.title} (Redline Draft v2)`,
      author: 'Eleanor Vance, Deputy General Counsel',
      recipients: ['Marcus Brody, VP Infrastructure', 'Legal Commercial Team'],
      privilegeBasis: 'Attorney-Client Privilege',
      descriptionOfContent: 'Legal analysis of vendor limitation of liability, IP telemetry ingestion risks, and proposed fallback counter-language.',
      redactionsApplied: 8,
    },
    {
      id: 'PL-002',
      timestamp: '2026-03-25 11:30 EST',
      matterNumber: matter.matterNumber,
      documentTitle: 'Contract Risk Evaluation Memo & Exposure Estimate',
      author: 'Eleanor Vance, Deputy General Counsel',
      recipients: ['EVP Operations', 'Chief Financial Officer'],
      privilegeBasis: 'Attorney Work Product',
      descriptionOfContent: 'Confidential assessment of potential financial damages under proposed Texas jurisdiction and 3-month IP indemnity sub-cap.',
      redactionsApplied: 12,
    },
    {
      id: 'PL-003',
      timestamp: '2026-03-12 09:00 EST',
      matterNumber: matter.matterNumber,
      documentTitle: 'Incoming Third-Party Vendor Form Agreement',
      author: 'Datavane Systems Legal Team',
      recipients: ['Apex Global Legal Department'],
      privilegeBasis: 'Attorney-Client Privilege',
      descriptionOfContent: 'Initial draft intake and legal screening against Corporate Standard Negotiation Playbook.',
      redactionsApplied: 4,
    }
  ];

  const handleExportCsv = () => {
    const csvContent = 
      'Log ID,Timestamp,Matter,Document Title,Author,Privilege Basis,Redactions,Description\n' +
      sampleLogEntries
        .map(e => `"${e.id}","${e.timestamp}","${e.matterNumber}","${e.documentTitle}","${e.author}","${e.privilegeBasis}",${e.redactionsApplied},"${e.descriptionOfContent.replace(/"/g, '""')}"`)
        .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `Privilege_Log_${matter.matterNumber}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-4xl rounded-xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h2 className="font-bold text-base text-white">Privilege Log & Legal Audit Trail</h2>
              <p className="text-xs text-slate-400">
                Formal evidentiary log maintaining Attorney-Client Privilege and Attorney Work Product doctrine protections
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Notice Box */}
        <div className="p-4 bg-amber-950/20 border-b border-amber-900/40 text-xs text-amber-200 space-y-1">
          <div className="font-semibold flex items-center gap-1.5 text-amber-300">
            <Lock className="w-3.5 h-3.5" />
            <span>CONFIDENTIAL // PREPARED FOR THE PURPOSE OF RENDERING LEGAL ADVICE</span>
          </div>
          <p className="text-slate-300 text-[11px] leading-relaxed">
            All reviews, redlines, and comments generated within this matter are protected from civil discovery and subpoena under Federal Rule of Evidence 502 and applicable state privilege rules.
          </p>
        </div>

        {/* Log Table */}
        <div className="p-4 overflow-x-auto max-h-96 overflow-y-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[10px] uppercase font-bold tracking-wider">
                <th className="py-2 px-3">Entry ID</th>
                <th className="py-2 px-3">Timestamp</th>
                <th className="py-2 px-3">Document / Analysis</th>
                <th className="py-2 px-3">Author</th>
                <th className="py-2 px-3">Privilege Basis</th>
                <th className="py-2 px-3">Redactions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {sampleLogEntries.map((entry) => (
                <tr key={entry.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-3 font-mono font-bold text-indigo-400">{entry.id}</td>
                  <td className="py-3 px-3 text-slate-400 text-[11px] whitespace-nowrap">{entry.timestamp}</td>
                  <td className="py-3 px-3">
                    <span className="font-semibold text-white block">{entry.documentTitle}</span>
                    <span className="text-[11px] text-slate-400 line-clamp-1">{entry.descriptionOfContent}</span>
                  </td>
                  <td className="py-3 px-3 text-slate-300 whitespace-nowrap">{entry.author}</td>
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-indigo-950 text-indigo-300 border border-indigo-800">
                      {entry.privilegeBasis}
                    </span>
                  </td>
                  <td className="py-3 px-3 font-mono text-emerald-400 font-bold text-center">
                    {entry.redactionsApplied}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs">
          <div className="text-slate-400 text-[11px]">
            Matter: <strong className="text-white font-mono">{matter.matterNumber}</strong> • Lead: {matter.leadCounsel}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportCsv}
              className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-md"
            >
              {downloadSuccess ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                  <span>Exported CSV</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>Export Privilege Log (CSV)</span>
                </>
              )}
            </button>
            <button
              onClick={onClose}
              className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
