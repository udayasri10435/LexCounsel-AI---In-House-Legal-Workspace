import React, { useState } from 'react';
import { Plus, X, Upload, FileText, Sparkles, Database, Check } from 'lucide-react';
import { Matter, PracticeArea, DmsType } from '../types/legal';

interface NewMatterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateMatter: (newMatter: Matter, contractText: string) => void;
}

export const NewMatterModal: React.FC<NewMatterModalProps> = ({
  isOpen,
  onClose,
  onCreateMatter,
}) => {
  const [title, setTitle] = useState('');
  const [counterparty, setCounterparty] = useState('');
  const [practiceArea, setPracticeArea] = useState<PracticeArea>('Commercial & SaaS');
  const [leadCounsel, setLeadCounsel] = useState('Eleanor Vance, Deputy General Counsel');
  const [clientBusinessUnit, setClientBusinessUnit] = useState('Enterprise Procurement');
  const [businessOwner, setBusinessOwner] = useState('Director of Strategic Sourcing');
  const [dmsProvider, setDmsProvider] = useState<DmsType>('iManage');
  const [riskTolerance, setRiskTolerance] = useState<'Low (Aggressive Protection)' | 'Moderate (Balanced)' | 'High (Expedited Close)'>('Low (Aggressive Protection)');
  const [contractText, setContractText] = useState('');

  if (!isOpen) return null;

  const handleLoadSample = () => {
    setTitle('CyberSentinel Managed Security Services Agreement');
    setCounterparty('CyberSentinel Global LLC');
    setContractText(`MANAGED SECURITY SERVICES MASTER AGREEMENT

This Agreement is entered into by CyberSentinel Global LLC ("Provider") and Customer.

1. SCOPE OF SERVICES
Provider will deliver managed threat detection, 24/7 SOC telemetry monitoring, and incident response services.

2. CUSTOMER DATA & ALGORITHMIC LEARNING
Provider may ingest, de-identify, and vectorize all customer security logs and packet payloads to train Provider's proprietary threat detection neural networks. Provider shall own all resulting threat models and synthetic embeddings.

3. LIMITATION OF LIABILITY
PROVIDER'S TOTAL AGGREGATE LIABILITY ARISING FROM THIS AGREEMENT OR SYSTEM DATA BREACHES SHALL NOT EXCEED $10,000 OR 1 MONTH OF FEES PAID. PROVIDER DISCLAIMS ALL INCIDENTAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES.

4. INDEMNIFICATION
Customer agrees to defend, indemnify, and hold harmless Provider against any third-party claims, government investigations, or regulatory fines arising from Customer's network incidents. Provider offers no intellectual property indemnification.

5. GOVERNING LAW & ARBITRATION
This Agreement shall be governed by the laws of Texas with mandatory binding individual arbitration in Dallas, TX.`);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !counterparty.trim() || !contractText.trim()) return;

    const newMatterId = `mat-${Date.now()}`;
    const matterNumber = `MAT-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    const newMatter: Matter = {
      id: newMatterId,
      matterNumber,
      title,
      practiceArea,
      leadCounsel,
      clientBusinessUnit,
      businessOwner,
      counterparty,
      status: 'In Review',
      privilegeLevel: 'ATTORNEY-CLIENT PRIVILEGED',
      riskTolerance,
      createdAt: new Date().toISOString().split('T')[0],
      targetClosingDate: '2026-05-15',
      dms: {
        provider: dmsProvider,
        workspaceId: `Wksp-CORP-${matterNumber}`,
        workspaceName: `LEGAL / 2026 / ${counterparty}`,
        documentId: `DOC-${Math.floor(10000 + Math.random() * 90000)}-01`,
        documentNumber: `#${Math.floor(10000 + Math.random() * 90000)}.1`,
        version: 1,
        isCheckedOut: true,
        checkedOutBy: leadCounsel,
        lastSyncedAt: 'Just now',
        cabinetOrDatabase: dmsProvider === 'iManage' ? 'ACTIVE_COMMERCIAL_CABINET_US' : 'ND_GLOBAL_LEGAL_CABINET'
      }
    };

    onCreateMatter(newMatter, contractText);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-3xl rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center">
              <Plus className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <h2 className="font-bold text-base text-white">Create In-House Legal Matter</h2>
              <p className="text-xs text-slate-400">
                Initiate matter dossier, configure DMS binding, and intake contract for AI review
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-5 text-xs">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-slate-300 font-semibold block mb-1">
                Matter Title: <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Snowflake Enterprise Cloud MSA"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-slate-950 text-slate-200 p-2.5 rounded-lg border border-slate-700 focus:outline-none focus:border-indigo-500 text-xs"
              />
            </div>

            <div>
              <label className="text-slate-300 font-semibold block mb-1">
                Counterparty Entity: <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Snowflake Inc."
                value={counterparty}
                onChange={(e) => setCounterparty(e.target.value)}
                className="w-full bg-slate-950 text-slate-200 p-2.5 rounded-lg border border-slate-700 focus:outline-none focus:border-indigo-500 text-xs"
              />
            </div>

            <div>
              <label className="text-slate-300 font-semibold block mb-1">
                Practice Area:
              </label>
              <select
                value={practiceArea}
                onChange={(e) => setPracticeArea(e.target.value as PracticeArea)}
                className="w-full bg-slate-950 text-slate-200 p-2.5 rounded-lg border border-slate-700 focus:outline-none focus:border-indigo-500 text-xs"
              >
                <option value="Commercial & SaaS">Commercial & SaaS</option>
                <option value="Corporate & M&A">Corporate & M&A</option>
                <option value="IP & Technology">IP & Technology</option>
                <option value="Privacy & Data Security">Privacy & Data Security</option>
                <option value="Employment & Labor">Employment & Labor</option>
                <option value="Vendor Procurement">Vendor Procurement</option>
              </select>
            </div>

            <div>
              <label className="text-slate-300 font-semibold block mb-1">
                DMS Binding:
              </label>
              <select
                value={dmsProvider}
                onChange={(e) => setDmsProvider(e.target.value as DmsType)}
                className="w-full bg-slate-950 text-slate-200 p-2.5 rounded-lg border border-slate-700 focus:outline-none focus:border-indigo-500 text-xs"
              >
                <option value="iManage">iManage Work 10 (Matter Workspace)</option>
                <option value="NetDocuments">NetDocuments (ND Cabinet)</option>
                <option value="Local Vault">Local In-House Vault</option>
              </select>
            </div>
          </div>

          {/* Contract Content Input */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-slate-300 font-semibold">
                Contract Text / Incoming Vendor Draft: <span className="text-rose-400">*</span>
              </label>
              <button
                type="button"
                onClick={handleLoadSample}
                className="text-[11px] text-indigo-400 hover:text-indigo-300 underline cursor-pointer"
              >
                Load Sample High-Risk Cybersecurity Agreement
              </button>
            </div>
            <textarea
              required
              rows={8}
              placeholder="Paste contract text, vendor draft clauses, or uploaded agreement text here..."
              value={contractText}
              onChange={(e) => setContractText(e.target.value)}
              className="w-full bg-slate-950 text-slate-200 p-3 rounded-lg border border-slate-700 focus:outline-none focus:border-indigo-500 font-mono text-xs leading-relaxed"
            />
          </div>

          {/* Footer Submit */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
            <span className="text-[11px] text-slate-400">
              Contract will be indexed, audited against Corporate Playbook, and screened for risk flags.
            </span>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!title.trim() || !counterparty.trim() || !contractText.trim()}
                className="px-5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold flex items-center gap-2 transition-colors cursor-pointer shadow-lg disabled:opacity-50"
              >
                <Sparkles className="w-4 h-4" />
                <span>Initialize Matter & Run AI Review</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
