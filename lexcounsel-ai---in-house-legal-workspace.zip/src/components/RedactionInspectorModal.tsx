import React from 'react';
import { EyeOff, X, ShieldCheck, Check, AlertCircle, Lock } from 'lucide-react';
import { RedactionRule } from '../types/legal';

interface RedactionInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  isRedactionActive: boolean;
  onToggleRedaction: () => void;
}

export const RedactionInspectorModal: React.FC<RedactionInspectorModalProps> = ({
  isOpen,
  onClose,
  isRedactionActive,
  onToggleRedaction,
}) => {
  if (!isOpen) return null;

  const defaultRules: RedactionRule[] = [
    {
      type: 'PII_NAME',
      label: 'Executive & In-House Counsel PII',
      regex: 'Marcus Brody, Eleanor Vance, Julian Sterling',
      mask: '[REDACTED_OFFICER_NAME]',
      enabled: true,
    },
    {
      type: 'FINANCIAL_AMOUNTS',
      label: 'Confidential Dollar Figures & Liability Thresholds',
      regex: '$5,000,000, $15,000,000, $37,500',
      mask: '[$CONFIDENTIAL_CAP_AMT]',
      enabled: true,
    },
    {
      type: 'SECRET_CODENAME',
      label: 'Internal Unannounced Project Codenames',
      regex: 'Project Apex, CloudCore, Kinesis 70B',
      mask: '[CLIENT_CORP_ALPHA]',
      enabled: true,
    },
    {
      type: 'CONFIDENTIAL_METRICS',
      label: 'Dispute Jurisdictions & Legal Seats',
      regex: 'Travis County, Austin, Texas',
      mask: '[CONFIDENTIAL_JURISDICTION]',
      enabled: true,
    },
    {
      type: 'CUSTOM',
      label: 'Corporate Counterparty Entity Masking',
      regex: 'Apex Global Enterprises, Inc.',
      mask: '[CLIENT_ENTERPRISE_IDENTIFIER]',
      enabled: true,
    }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-2xl rounded-xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center">
              <EyeOff className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h2 className="font-bold text-base text-white">Privilege-Safe Sanitizer & PII Masking</h2>
              <p className="text-xs text-slate-400">
                Client-side heuristic sanitization preventing data exposure to external model endpoints
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Master Toggle Banner */}
        <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-white block">
              Active Sanitization Status
            </span>
            <span className="text-[11px] text-slate-400">
              When active, client-side browser regex replaces sensitive tokens prior to any analysis.
            </span>
          </div>

          <button
            onClick={onToggleRedaction}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer border ${
              isRedactionActive
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white border-emerald-400 shadow-md'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
            }`}
          >
            {isRedactionActive ? 'Shield ACTIVE (Masked)' : 'Shield DISABLED'}
          </button>
        </div>

        {/* Rules Table */}
        <div className="p-5 space-y-3">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
            Applied Client-Side Masking Patterns:
          </span>

          <div className="space-y-2">
            {defaultRules.map((rule, idx) => (
              <div 
                key={idx} 
                className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between text-xs"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-white">{rule.label}</span>
                    <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-slate-900 text-slate-400 border border-slate-800">
                      {rule.type}
                    </span>
                  </div>
                  <div className="mt-1 flex items-center gap-2 text-[11px] text-slate-400 font-mono">
                    <span className="text-rose-300/80 line-through">{rule.regex}</span>
                    <span>→</span>
                    <span className="text-emerald-400 font-bold">{rule.mask}</span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 text-emerald-400 text-xs font-medium">
                  <Check className="w-3.5 h-3.5" />
                  <span>Enforced</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Security Assurance Guarantee */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Zero-Retention VPC Proxy • No Human Review • SOC-2 Type II Certified</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
