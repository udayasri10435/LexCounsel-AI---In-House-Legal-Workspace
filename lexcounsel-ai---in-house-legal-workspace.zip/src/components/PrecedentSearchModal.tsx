import React, { useState } from 'react';
import { 
  BookOpen, 
  Search, 
  X, 
  Check, 
  Copy, 
  Filter, 
  ExternalLink, 
  FileText, 
  Scale, 
  Building2, 
  Calendar,
  Sparkles
} from 'lucide-react';
import { Precedent } from '../types/legal';

interface PrecedentSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  precedents: Precedent[];
  selectedPrecedent: Precedent | null;
  onApplyPrecedent: (precedent: Precedent) => void;
}

export const PrecedentSearchModal: React.FC<PrecedentSearchModalProps> = ({
  isOpen,
  onClose,
  precedents,
  selectedPrecedent: initialSelected,
  onApplyPrecedent,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [activePrecedent, setActivePrecedent] = useState<Precedent | null>(
    initialSelected || precedents[0] || null
  );
  const [copied, setCopied] = useState(false);

  // Sync if initialSelected changes
  React.useEffect(() => {
    if (initialSelected) setActivePrecedent(initialSelected);
  }, [initialSelected]);

  if (!isOpen) return null;

  const categories = ['ALL', 'Limitation of Liability', 'IP Ownership & Licensing', 'Indemnification', 'Termination & Cure', 'Data Privacy & Security', 'Warranties & Disclaimers'];

  const filteredPrecedents = precedents.filter((p) => {
    const matchesSearch = 
      p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.counterparty.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.concessionNotes.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.negotiatedText.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCat = selectedCategory === 'ALL' || p.clauseCategory === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-5xl rounded-xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center">
              <BookOpen className="w-4 h-4 text-indigo-400" />
            </div>
            <div>
              <h2 className="font-bold text-base text-white">In-House Executed Precedent Library</h2>
              <p className="text-xs text-slate-400">
                Gold-standard negotiated language from executed deals (Snowflake, AWS, Salesforce, Workday)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter and Search Bar */}
        <div className="p-3 bg-slate-950/80 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="relative flex-1 min-w-[260px]">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              placeholder="Search executed precedent agreements, concessions, parties..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-900 text-slate-200 placeholder-slate-500 pl-9 pr-3 py-1.5 rounded-lg border border-slate-700 focus:outline-none focus:border-indigo-500 text-xs"
            />
          </div>

          <div className="flex items-center gap-1 overflow-x-auto text-[11px]">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {cat === 'ALL' ? 'All Clauses' : cat}
              </button>
            ))}
          </div>
        </div>

        {/* Main Split Body: Left List, Right Detail */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 min-h-0 overflow-hidden divide-y md:divide-y-0 md:divide-x divide-slate-800">
          {/* Precedent List (Left 5 Cols) */}
          <div className="md:col-span-5 overflow-y-auto p-3 space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 px-1 block">
              Executed Precedents ({filteredPrecedents.length})
            </span>
            {filteredPrecedents.map((prec) => {
              const isSelected = prec.id === activePrecedent?.id;
              return (
                <div
                  key={prec.id}
                  onClick={() => setActivePrecedent(prec)}
                  className={`p-3 rounded-lg border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-indigo-950/70 border-indigo-500 shadow-md ring-1 ring-indigo-500'
                      : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-800/50'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-bold text-white truncate max-w-[200px]">
                      {prec.counterparty}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-indigo-950 text-indigo-300 border border-indigo-800">
                      {prec.similarityScore}% Match
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 font-medium mb-1 truncate">
                    {prec.title}
                  </p>

                  <div className="flex items-center gap-2 text-[10px] text-slate-400 mb-2">
                    <span className="px-1.5 py-0.2 rounded bg-slate-900 border border-slate-800">{prec.clauseCategory}</span>
                    <span>•</span>
                    <span>{prec.governingLaw} Law</span>
                  </div>

                  <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                    {prec.concessionNotes}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Precedent Inspection View (Right 7 Cols) */}
          <div className="md:col-span-7 overflow-y-auto p-4 md:p-6 bg-slate-900 space-y-4">
            {activePrecedent ? (
              <>
                {/* Header Information */}
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-indigo-400">
                        {activePrecedent.matterNumber}
                      </span>
                      <span className="text-slate-600">|</span>
                      <span className="text-xs text-slate-300">DMS: <strong className="text-sky-400 font-mono">{activePrecedent.dmsDocId}</strong></span>
                    </div>
                    <span className="text-[11px] text-slate-400 flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-slate-500" /> Executed: {activePrecedent.negotiatedDate}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-white">
                    {activePrecedent.title}
                  </h3>

                  <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 pt-1 border-t border-slate-800/80">
                    <span>Counterparty: <strong className="text-slate-200">{activePrecedent.counterparty}</strong></span>
                    <span>•</span>
                    <span>Lead Counsel: <strong className="text-slate-200">{activePrecedent.leadCounselName}</strong></span>
                    <span>•</span>
                    <span>Jurisdiction: <strong className="text-slate-200">{activePrecedent.governingLaw}</strong></span>
                  </div>
                </div>

                {/* Concession & Negotiation Intelligence */}
                <div className="p-4 rounded-xl bg-amber-950/20 border border-amber-900/40 space-y-1.5">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-amber-300">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span>In-House Negotiation Playbook Note</span>
                  </div>
                  <p className="text-xs text-amber-100/90 leading-relaxed font-sans">
                    {activePrecedent.concessionNotes}
                  </p>
                </div>

                {/* Executed Clause Text Box */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                      Negotiated & Executed Contract Language:
                    </span>
                    <button
                      onClick={() => handleCopy(activePrecedent.negotiatedText)}
                      className="flex items-center gap-1 text-xs text-slate-400 hover:text-white px-2 py-1 rounded bg-slate-800 border border-slate-700 transition-colors cursor-pointer"
                    >
                      {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copied ? 'Copied' : 'Copy Clause'}</span>
                    </button>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-emerald-300/95 leading-relaxed whitespace-pre-wrap selection:bg-emerald-900 shadow-inner">
                    {activePrecedent.negotiatedText}
                  </div>
                </div>

                {/* Apply Precedent CTA */}
                <div className="pt-2 flex items-center justify-end gap-3">
                  <button
                    onClick={onClose}
                    className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium cursor-pointer"
                  >
                    Close
                  </button>
                  <button
                    onClick={() => {
                      onApplyPrecedent(activePrecedent);
                      onClose();
                    }}
                    className="px-5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-colors cursor-pointer shadow-lg flex items-center gap-2"
                  >
                    <Check className="w-4 h-4" />
                    <span>Apply Precedent Language to Active Redline</span>
                  </button>
                </div>
              </>
            ) : (
              <div className="h-full flex items-center justify-center text-slate-500 text-xs">
                Select a precedent from the list to review executed terms.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
