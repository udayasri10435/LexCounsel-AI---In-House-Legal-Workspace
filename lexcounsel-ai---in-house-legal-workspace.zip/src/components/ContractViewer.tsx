import React, { useState, useMemo } from 'react';
import { 
  FileText, 
  Search, 
  Check, 
  Copy, 
  Download, 
  Eye, 
  Edit3, 
  CheckCircle, 
  AlertTriangle, 
  Layers, 
  RotateCcw,
  Sparkles,
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { LegalContract, Clause, RiskSeverity } from '../types/legal';

interface ContractViewerProps {
  contract: LegalContract;
  activeClauseId: string | null;
  onSelectClause: (clauseId: string) => void;
  onAcceptRedline: (clauseId: string) => void;
  onUpdateContractContent: (newContent: string) => void;
  onGenerateCustomRedline: (clause: Clause) => void;
  isRedactionActive: boolean;
}

export const ContractViewer: React.FC<ContractViewerProps> = ({
  contract,
  activeClauseId,
  onSelectClause,
  onAcceptRedline,
  onUpdateContractContent,
  onGenerateCustomRedline,
  isRedactionActive,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState<'interactive' | 'diff' | 'clean'>('interactive');
  const [isEditing, setIsEditing] = useState(false);
  const [editableText, setEditableText] = useState(contract.content);
  const [copied, setCopied] = useState(false);

  // Sync editable text when contract content changes
  React.useEffect(() => {
    setEditableText(contract.content);
  }, [contract.content]);

  // Mask text for Privilege-Safe mode if enabled
  const displayedText = useMemo(() => {
    let text = contract.content;
    if (isRedactionActive) {
      text = text
        .replace(/Marcus Brody/g, '[REDACTED_VP_INFRA]')
        .replace(/Eleanor Vance/g, '[REDACTED_DEPUTY_GC]')
        .replace(/Apex Global Enterprises, Inc\./g, '[CLIENT_CORP_ALPHA]')
        .replace(/Datavane Systems, Inc\./g, '[VENDOR_ENTITY_01]')
        .replace(/\$5,000,000/g, '[$CONFIDENTIAL_CAP_AMT]')
        .replace(/\$15,000,000/g, '[$CONFIDENTIAL_EXPOSURE_AMT]')
        .replace(/Travis County, Austin, Texas/g, '[CONFIDENTIAL_JURISDICTION]');
    }
    return text;
  }, [contract.content, isRedactionActive]);

  const lines = useMemo(() => displayedText.split('\n'), [displayedText]);

  const handleCopy = () => {
    navigator.clipboard.writeText(contract.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSaveEdit = () => {
    onUpdateContractContent(editableText);
    setIsEditing(false);
  };

  // Find active clause object
  const activeClause = contract.clauses.find(c => c.id === activeClauseId);

  return (
    <div className="flex-1 flex flex-col bg-slate-900 border-r border-slate-800 min-h-0 overflow-hidden">
      {/* Contract Viewer Toolbar */}
      <div className="bg-slate-950 px-4 py-2.5 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <FileText className="w-4 h-4 text-indigo-400" />
          <span className="font-semibold text-slate-200 truncate max-w-sm">
            {contract.title}
          </span>
          <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-300 border border-slate-700">
            {contract.version}
          </span>
          <span className="text-slate-500">•</span>
          <span className="text-slate-400">{lines.length} lines</span>
        </div>

        <div className="flex items-center gap-2.5">
          {/* Search Bar */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              placeholder="Search in contract (e.g. indemnity, liability)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-slate-900 text-slate-200 placeholder-slate-500 pl-8 pr-3 py-1 rounded text-xs border border-slate-700 focus:outline-none focus:border-indigo-500 w-64 transition-all"
            />
          </div>

          {/* View Mode Selector */}
          <div className="flex items-center rounded bg-slate-900 p-0.5 border border-slate-800">
            <button
              onClick={() => { setViewMode('interactive'); setIsEditing(false); }}
              className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors cursor-pointer ${
                viewMode === 'interactive' && !isEditing
                  ? 'bg-indigo-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Annotated
            </button>
            <button
              onClick={() => { setViewMode('diff'); setIsEditing(false); }}
              className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors cursor-pointer ${
                viewMode === 'diff' && !isEditing
                  ? 'bg-indigo-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Redline Diff
            </button>
            <button
              onClick={() => { setViewMode('clean'); setIsEditing(false); }}
              className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors cursor-pointer ${
                viewMode === 'clean' && !isEditing
                  ? 'bg-indigo-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Clean Text
            </button>
          </div>

          {/* Edit / Save Button */}
          {isEditing ? (
            <div className="flex items-center gap-1.5">
              <button
                onClick={handleSaveEdit}
                className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs flex items-center gap-1 transition-colors cursor-pointer"
              >
                <Check className="w-3 h-3" /> Save Changes
              </button>
              <button
                onClick={() => { setEditableText(contract.content); setIsEditing(false); }}
                className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition-colors cursor-pointer"
              >
                Cancel
              </button>
            </div>
          ) : (
            <button
              onClick={() => setIsEditing(true)}
              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-xs flex items-center gap-1 transition-colors cursor-pointer"
              title="Direct manual clause edit"
            >
              <Edit3 className="w-3 h-3" /> Edit Raw
            </button>
          )}

          {/* Copy Button */}
          <button
            onClick={handleCopy}
            className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 transition-colors cursor-pointer"
            title="Copy contract text to clipboard"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Clause Quick Filter Navigation Pill Bar */}
      <div className="bg-slate-900/90 px-4 py-1.5 border-b border-slate-800/80 flex items-center gap-2 overflow-x-auto text-[11px]">
        <span className="text-slate-500 font-semibold uppercase tracking-wider text-[10px] whitespace-nowrap">
          Jump to Clause:
        </span>
        {contract.clauses.map((clause) => {
          const isActive = clause.id === activeClauseId;
          const isHigh = clause.riskSeverity === 'HIGH';
          const isMed = clause.riskSeverity === 'MEDIUM';

          return (
            <button
              key={clause.id}
              onClick={() => onSelectClause(clause.id)}
              className={`px-2.5 py-0.5 rounded-full whitespace-nowrap font-medium transition-all flex items-center gap-1.5 cursor-pointer border ${
                isActive
                  ? 'bg-indigo-600 text-white border-indigo-400 shadow-sm'
                  : isHigh
                  ? 'bg-rose-950/40 text-rose-300 border-rose-800/60 hover:bg-rose-900/50'
                  : isMed
                  ? 'bg-amber-950/40 text-amber-300 border-amber-800/60 hover:bg-amber-900/50'
                  : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
              }`}
            >
              <span className={`w-1.5 h-1.5 rounded-full ${isHigh ? 'bg-rose-400' : isMed ? 'bg-amber-400' : 'bg-emerald-400'}`} />
              <span>{clause.clauseNumber} ({clause.category.split(' ')[0]})</span>
              {clause.suggestedRedline.accepted && (
                <Check className="w-3 h-3 text-emerald-400" />
              )}
            </button>
          );
        })}
      </div>

      {/* Main Contract Content Area */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6 font-mono text-sm leading-relaxed text-slate-300 selection:bg-indigo-500 selection:text-white">
        {isEditing ? (
          <textarea
            value={editableText}
            onChange={(e) => setEditableText(e.target.value)}
            className="w-full h-full bg-slate-950 text-slate-200 p-4 rounded-lg font-mono text-xs leading-relaxed border border-slate-700 focus:outline-none focus:border-indigo-500 resize-none shadow-inner"
            placeholder="Edit legal contract text directly..."
          />
        ) : viewMode === 'diff' ? (
          /* Redline Diff Mode */
          <div className="space-y-6">
            <div className="p-3 rounded-lg bg-indigo-950/40 border border-indigo-800/50 text-xs text-indigo-300 mb-4 flex items-center justify-between">
              <div>
                <strong className="text-white">Redline Diff View:</strong> Comparing incoming Vendor Draft against Company In-House Legal Preferred Positions.
              </div>
              <div className="flex items-center gap-3 text-[11px]">
                <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-rose-500 inline-block" /> Vendor Language Struck</span>
                <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-emerald-500 inline-block" /> In-House Counter Inserted</span>
              </div>
            </div>

            {contract.clauses.map((clause, idx) => (
              <div 
                key={clause.id}
                className={`p-4 rounded-lg border transition-all ${
                  clause.id === activeClauseId 
                    ? 'bg-slate-900 border-indigo-500 shadow-lg ring-1 ring-indigo-500' 
                    : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between pb-2 border-b border-slate-800/80 mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white uppercase tracking-wider">{clause.clauseNumber}</span>
                    <span className="text-xs text-slate-400">• {clause.title}</span>
                    <span className={`px-2 py-0.2 rounded text-[10px] font-semibold ${
                      clause.riskSeverity === 'HIGH' ? 'bg-rose-900/60 text-rose-300 border border-rose-700' :
                      clause.riskSeverity === 'MEDIUM' ? 'bg-amber-900/60 text-amber-300 border border-amber-700' :
                      'bg-emerald-900/60 text-emerald-300 border border-emerald-700'
                    }`}>
                      {clause.riskSeverity} RISK
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {clause.suggestedRedline.accepted ? (
                      <span className="flex items-center gap-1 text-xs text-emerald-400 font-semibold">
                        <CheckCircle className="w-3.5 h-3.5" /> Redline Accepted
                      </span>
                    ) : (
                      <button
                        onClick={() => onAcceptRedline(clause.id)}
                        className="px-2.5 py-1 rounded bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-medium flex items-center gap-1 transition-colors cursor-pointer shadow-sm"
                      >
                        <Check className="w-3 h-3" /> Accept Counter
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-sans">
                  <div className="p-3 rounded bg-rose-950/20 border border-rose-900/30">
                    <div className="text-[11px] font-semibold text-rose-400 mb-1 flex items-center gap-1">
                      <span>Incoming Vendor Language:</span>
                    </div>
                    <p className="text-rose-200/90 leading-relaxed font-mono whitespace-pre-wrap">
                      {clause.originalText}
                    </p>
                  </div>

                  <div className="p-3 rounded bg-emerald-950/20 border border-emerald-900/30">
                    <div className="text-[11px] font-semibold text-emerald-400 mb-1 flex items-center justify-between">
                      <span>In-House Proposed Counter:</span>
                      <span className="text-[10px] text-emerald-400 font-normal">Playbook Compliant</span>
                    </div>
                    <p className="text-emerald-200/90 leading-relaxed font-mono whitespace-pre-wrap">
                      {clause.suggestedRedline.proposedText}
                    </p>
                  </div>
                </div>

                <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400 font-sans">
                  <div>
                    <strong className="text-slate-300">Counsel Rationale:</strong> {clause.suggestedRedline.rationale}
                  </div>
                  <button
                    onClick={() => onSelectClause(clause.id)}
                    className="text-indigo-400 hover:text-indigo-300 text-xs font-medium underline flex items-center gap-0.5 cursor-pointer ml-4 whitespace-nowrap"
                  >
                    View Details & Precedents <ChevronRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          /* Interactive Annotated View */
          <div className="space-y-1">
            {lines.map((line, idx) => {
              const lineNum = idx + 1;
              const isSectionHeader = /^SECTION \d+/i.test(line.trim());
              const isRecital = /^(WHEREAS|NOW, THEREFORE|RECITALS)/i.test(line.trim());
              
              // Check if line falls within any flagged clause
              const matchedClause = contract.clauses.find(
                c => lineNum >= c.lineNumberStart && lineNum <= c.lineNumberEnd
              );

              const isClauseStart = matchedClause && matchedClause.lineNumberStart === lineNum;
              const isHighlightedSearch = searchTerm && line.toLowerCase().includes(searchTerm.toLowerCase());

              return (
                <div key={idx}>
                  {/* Inline Clause Banner if starting a flagged section */}
                  {isClauseStart && (
                    <div className={`my-2 p-2 rounded-t border text-xs font-sans flex items-center justify-between ${
                      matchedClause.riskSeverity === 'HIGH'
                        ? 'bg-rose-950/60 border-rose-700/80 text-rose-200'
                        : matchedClause.riskSeverity === 'MEDIUM'
                        ? 'bg-amber-950/60 border-amber-700/80 text-amber-200'
                        : 'bg-emerald-950/60 border-emerald-700/80 text-emerald-200'
                    }`}>
                      <div className="flex items-center gap-2">
                        <AlertTriangle className={`w-3.5 h-3.5 ${
                          matchedClause.riskSeverity === 'HIGH' ? 'text-rose-400' : 'text-amber-400'
                        }`} />
                        <span className="font-bold uppercase tracking-wider">
                          {matchedClause.clauseNumber}: {matchedClause.title}
                        </span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-black/40 font-mono">
                          {matchedClause.riskSeverity} RISK
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        {matchedClause.suggestedRedline.accepted ? (
                          <span className="text-emerald-400 font-semibold text-[11px] flex items-center gap-1">
                            <Check className="w-3 h-3" /> Counter Applied
                          </span>
                        ) : (
                          <button
                            onClick={() => onAcceptRedline(matchedClause.id)}
                            className="px-2 py-0.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-semibold cursor-pointer shadow-sm"
                          >
                            Accept Counter
                          </button>
                        )}
                        <button
                          onClick={() => onSelectClause(matchedClause.id)}
                          className="px-2 py-0.5 rounded bg-indigo-700 hover:bg-indigo-600 text-white text-[11px] font-semibold cursor-pointer"
                        >
                          Review Redline →
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Standard Line Display */}
                  <div
                    onClick={() => {
                      if (matchedClause) onSelectClause(matchedClause.id);
                    }}
                    className={`flex items-start gap-4 px-2 py-0.5 rounded transition-colors group cursor-text ${
                      matchedClause
                        ? matchedClause.id === activeClauseId
                          ? 'bg-indigo-950/60 text-slate-100 border-l-4 border-indigo-400 pl-1 cursor-pointer'
                          : matchedClause.riskSeverity === 'HIGH'
                          ? 'bg-rose-950/20 text-rose-100/90 border-l-2 border-rose-500/50 cursor-pointer hover:bg-rose-950/40'
                          : 'bg-amber-950/20 text-amber-100/90 border-l-2 border-amber-500/50 cursor-pointer hover:bg-amber-950/40'
                        : 'hover:bg-slate-800/40'
                    } ${isHighlightedSearch ? 'bg-yellow-500/20 text-yellow-200' : ''}`}
                  >
                    <span className="w-8 shrink-0 text-right text-xs text-slate-600 select-none group-hover:text-slate-400 font-mono">
                      {lineNum}
                    </span>
                    <span className={`flex-1 text-xs whitespace-pre-wrap ${
                      isSectionHeader ? 'font-bold text-white pt-3 pb-1 text-sm' :
                      isRecital ? 'italic text-slate-400' : ''
                    }`}>
                      {line || '\u00A0'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Floating Counsel Quick Action Bar at bottom */}
      {activeClause && (
        <div className="bg-slate-950 px-4 py-3 border-t border-slate-800 flex items-center justify-between gap-4 text-xs shadow-2xl">
          <div className="flex items-center gap-2.5 min-w-0">
            <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${
              activeClause.riskSeverity === 'HIGH' ? 'bg-rose-400 animate-pulse' : 'bg-amber-400'
            }`} />
            <div className="min-w-0">
              <span className="font-semibold text-white">Active Focus: {activeClause.clauseNumber} ({activeClause.title})</span>
              <p className="text-[11px] text-slate-400 truncate">{activeClause.riskSummary}</p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => onGenerateCustomRedline(activeClause)}
              className="px-3 py-1.5 rounded bg-indigo-900 hover:bg-indigo-800 border border-indigo-700 text-indigo-200 text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-sm"
              title="Generate new AI fallback redline with Gemini 3.8 Flash"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-300" />
              <span>Regenerate AI Redline</span>
            </button>

            {activeClause.suggestedRedline.accepted ? (
              <span className="px-3 py-1.5 rounded bg-emerald-950 border border-emerald-700 text-emerald-300 font-semibold text-xs flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5" /> Accepted in Draft
              </span>
            ) : (
              <button
                onClick={() => onAcceptRedline(activeClause.id)}
                className="px-3.5 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-md"
              >
                <Check className="w-3.5 h-3.5" /> Accept Redline
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
