import React, { useState, useMemo } from 'react';
import { 
  INITIAL_MATTERS, 
  SAMPLE_CONTRACTS 
} from './data/sampleMatters';
import { EXECUTED_PRECEDENTS } from './data/precedentsData';
import { Matter, LegalContract, Clause, Precedent, DmsMetadata } from './types/legal';
import { Header } from './components/Header';
import { PrivilegeBanner } from './components/PrivilegeBanner';
import { ContractViewer } from './components/ContractViewer';
import { RiskHeatmapPanel } from './components/RiskHeatmapPanel';
import { CounselCopilot } from './components/CounselCopilot';
import { PrecedentSearchModal } from './components/PrecedentSearchModal';
import { DmsIntegrationModal } from './components/DmsIntegrationModal';
import { PrivilegeLogModal } from './components/PrivilegeLogModal';
import { RedactionInspectorModal } from './components/RedactionInspectorModal';
import { ExecutiveSummaryModal } from './components/ExecutiveSummaryModal';
import { MatterDossierModal } from './components/MatterDossierModal';
import { NewMatterModal } from './components/NewMatterModal';
import { generateRedlineAPI, analyzeContractAPI } from './services/geminiLegalService';

export default function App() {
  const [matters, setMatters] = useState<Matter[]>(INITIAL_MATTERS);
  const [activeMatter, setActiveMatter] = useState<Matter>(INITIAL_MATTERS[0]);
  const [contracts, setContracts] = useState<Record<string, LegalContract>>(SAMPLE_CONTRACTS);
  const [precedents, setPrecedents] = useState<Precedent[]>(EXECUTED_PRECEDENTS);
  
  const [activeClauseId, setActiveClauseId] = useState<string | null>(
    SAMPLE_CONTRACTS['mat-001']?.clauses[0]?.id || null
  );

  // Modal & Panel visibility states
  const [isCopilotOpen, setIsCopilotOpen] = useState(false);
  const [isRedactionActive, setIsRedactionActive] = useState(true);
  const [isDmsModalOpen, setIsDmsModalOpen] = useState(false);
  const [isPrecedentsModalOpen, setIsPrecedentsModalOpen] = useState(false);
  const [isPrivilegeModalOpen, setIsPrivilegeModalOpen] = useState(false);
  const [isRedactionModalOpen, setIsRedactionModalOpen] = useState(false);
  const [isExecutiveSummaryOpen, setIsExecutiveSummaryOpen] = useState(false);
  const [isMatterDossierOpen, setIsMatterDossierOpen] = useState(false);
  const [isNewMatterModalOpen, setIsNewMatterModalOpen] = useState(false);
  const [selectedPrecedentForDetail, setSelectedPrecedentForDetail] = useState<Precedent | null>(null);

  // Active contract resolution
  const activeContract = useMemo(() => {
    return contracts[activeMatter.id] || SAMPLE_CONTRACTS['mat-001'];
  }, [contracts, activeMatter.id]);

  // Handle Matter selection
  const handleSelectMatter = (matter: Matter) => {
    setActiveMatter(matter);
    const contract = contracts[matter.id];
    if (contract && contract.clauses.length > 0) {
      setActiveClauseId(contract.clauses[0].id);
    } else {
      setActiveClauseId(null);
    }
  };

  // Handle accepting a proposed redline
  const handleAcceptRedline = (clauseId: string) => {
    if (!activeContract) return;

    const clause = activeContract.clauses.find(c => c.id === clauseId);
    if (!clause) return;

    // Substitute text in contract content
    let updatedContent = activeContract.content;
    if (clause.originalText && updatedContent.includes(clause.originalText)) {
      updatedContent = updatedContent.replace(clause.originalText, clause.suggestedRedline.proposedText);
    }

    // Update clauses accepted state
    const updatedClauses = activeContract.clauses.map(c => {
      if (c.id === clauseId) {
        return {
          ...c,
          suggestedRedline: {
            ...c.suggestedRedline,
            accepted: true,
          }
        };
      }
      return c;
    });

    // Recalculate risk score
    const unmitigatedHigh = updatedClauses.filter(c => c.riskSeverity === 'HIGH' && !c.suggestedRedline.accepted).length;
    const unmitigatedMed = updatedClauses.filter(c => c.riskSeverity === 'MEDIUM' && !c.suggestedRedline.accepted).length;
    const newScore = Math.max(15, unmitigatedHigh * 20 + unmitigatedMed * 10);

    const updatedContract: LegalContract = {
      ...activeContract,
      content: updatedContent,
      clauses: updatedClauses,
      overallRiskScore: newScore,
      highRiskCount: unmitigatedHigh,
      medRiskCount: unmitigatedMed,
      version: `${activeContract.version} (In-House Redlines Accepted)`,
      lastModified: 'Just now',
    };

    setContracts(prev => ({
      ...prev,
      [activeMatter.id]: updatedContract,
    }));
  };

  // Handle applying a precedent clause
  const handleApplyPrecedent = (precedent: Precedent) => {
    if (!activeContract || !activeClauseId) return;

    const updatedClauses = activeContract.clauses.map(c => {
      if (c.id === activeClauseId) {
        return {
          ...c,
          suggestedRedline: {
            ...c.suggestedRedline,
            proposedText: precedent.negotiatedText,
            rationale: `Applied from ${precedent.title} (${precedent.concessionNotes})`,
            accepted: true,
          }
        };
      }
      return c;
    });

    // Also replace in text
    const activeClause = activeContract.clauses.find(c => c.id === activeClauseId);
    let updatedContent = activeContract.content;
    if (activeClause && updatedContent.includes(activeClause.originalText)) {
      updatedContent = updatedContent.replace(activeClause.originalText, precedent.negotiatedText);
    }

    const unmitigatedHigh = updatedClauses.filter(c => c.riskSeverity === 'HIGH' && !c.suggestedRedline.accepted).length;
    const unmitigatedMed = updatedClauses.filter(c => c.riskSeverity === 'MEDIUM' && !c.suggestedRedline.accepted).length;
    const newScore = Math.max(15, unmitigatedHigh * 20 + unmitigatedMed * 10);

    const updatedContract: LegalContract = {
      ...activeContract,
      content: updatedContent,
      clauses: updatedClauses,
      overallRiskScore: newScore,
      highRiskCount: unmitigatedHigh,
      medRiskCount: unmitigatedMed,
    };

    setContracts(prev => ({
      ...prev,
      [activeMatter.id]: updatedContract,
    }));
  };

  // Handle generating a custom AI redline for an active clause
  const handleGenerateCustomRedline = async (clause: Clause) => {
    try {
      const result = await generateRedlineAPI(
        clause.category,
        clause.originalText,
        clause.playbookStandard,
        true // request compromise fallback
      );

      const updatedClauses = activeContract.clauses.map(c => {
        if (c.id === clause.id) {
          return {
            ...c,
            suggestedRedline: {
              ...c.suggestedRedline,
              proposedText: result.proposedText || result.redlineText || c.suggestedRedline.proposedText,
              rationale: result.counselRationale || result.rationale || c.suggestedRedline.rationale,
              fallbackPosition: result.talkTrackForVendor || c.suggestedRedline.fallbackPosition,
            }
          };
        }
        return c;
      });

      setContracts(prev => ({
        ...prev,
        [activeMatter.id]: {
          ...activeContract,
          clauses: updatedClauses,
        }
      }));
    } catch (err: any) {
      console.error('Failed to generate custom redline:', err);
    }
  };

  // Handle direct text updates in contract editor
  const handleUpdateContractContent = (newContent: string) => {
    setContracts(prev => ({
      ...prev,
      [activeMatter.id]: {
        ...activeContract,
        content: newContent,
        lastModified: 'Just now (Manual Edit)',
      }
    }));
  };

  // Handle DMS metadata sync
  const handleUpdateDms = (updatedDms: DmsMetadata) => {
    const updatedMatter: Matter = {
      ...activeMatter,
      dms: updatedDms,
    };

    setActiveMatter(updatedMatter);
    setMatters(prev => prev.map(m => m.id === updatedMatter.id ? updatedMatter : m));
  };

  // Handle New Matter creation with AI Analysis
  const handleCreateNewMatter = async (newMatter: Matter, contractText: string) => {
    let initialScore = 70;
    let clauses: Clause[] = [];

    try {
      const analysis = await analyzeContractAPI(contractText, newMatter);
      initialScore = analysis.overallRiskScore || analysis.riskScore || 70;

      if (analysis.extractedClauses && analysis.extractedClauses.length > 0) {
        clauses = analysis.extractedClauses.map((ec, idx) => ({
          id: `new-cl-${Date.now()}-${idx}`,
          title: ec.title || `${ec.category} Clause`,
          category: ec.category as any,
          clauseNumber: ec.clauseNumber || `Section ${idx + 1}`,
          lineNumberStart: idx * 8 + 1,
          lineNumberEnd: idx * 8 + 7,
          riskSeverity: ec.riskSeverity || 'HIGH',
          riskSummary: ec.riskSummary || 'Clause deviates from standard corporate playbook',
          playbookStandard: 'Company corporate legal standard policy position',
          playbookDeviation: ec.playbookDeviation || 'Vendor proposal creates unmitigated legal risk',
          originalText: `Excerpt from ${ec.category} under review...`,
          suggestedRedline: {
            proposedText: ec.proposedRedline || 'Standard reciprocal in-house counter-language',
            diffMarkup: '<del>Vendor</del> <ins>Customer standard</ins>',
            rationale: ec.negotiationRationale || 'Maintains corporate risk standards',
            fallbackPosition: ec.fallbackPosition || 'Secondary compromise position',
            accepted: false,
          }
        }));
      }
    } catch (err) {
      console.warn('API analysis fallback to default playbook parsing:', err);
    }

    // Default fallback clauses if none extracted
    if (clauses.length === 0) {
      clauses = [
        {
          id: `new-cl-default-1`,
          title: 'Limitation of Liability & Indemnity',
          category: 'Limitation of Liability',
          clauseNumber: 'Section 3',
          lineNumberStart: 10,
          lineNumberEnd: 15,
          riskSeverity: 'HIGH',
          riskSummary: 'Nominal $10,000 liability cap and disclaimer of incidental damages.',
          playbookStandard: 'Mutual 2x annual contract spend with $5M super-cap.',
          playbookDeviation: 'Violates Rule LL-01: Cap under $1M unacceptable for enterprise infrastructure.',
          originalText: 'PROVIDER\'S TOTAL AGGREGATE LIABILITY ARISING FROM THIS AGREEMENT OR SYSTEM DATA BREACHES SHALL NOT EXCEED $10,000 OR 1 MONTH OF FEES PAID.',
          suggestedRedline: {
            proposedText: 'EACH PARTY\'S TOTAL AGGREGATE LIABILITY ARISING OUT OF OR RELATED TO THIS AGREEMENT SHALL BE LIMITED TO TWO TIMES (2X) THE ANNUAL FEES PAID OR PAYABLE...',
            diffMarkup: '<del>$10,000</del> <ins>TWO TIMES (2X) ANNUAL FEES</ins>',
            rationale: 'Aligns with enterprise market standards.',
            fallbackPosition: 'Minimum $1M liability cap.',
            accepted: false,
          }
        },
        {
          id: `new-cl-default-2`,
          title: 'AI Model Training on Customer Data',
          category: 'IP Ownership & Licensing',
          clauseNumber: 'Section 2',
          lineNumberStart: 6,
          lineNumberEnd: 9,
          riskSeverity: 'HIGH',
          riskSummary: 'Vendor claims right to ingest and vectorize customer security logs for AI model training.',
          playbookStandard: 'Customer retains 100% exclusive ownership. Vendor strictly prohibited from model training.',
          playbookDeviation: 'Violates Rule IP-03: Prohibits enterprise telemetry ingestion into commercial AI models.',
          originalText: 'Provider may ingest, de-identify, and vectorize all customer security logs and packet payloads to train Provider\'s proprietary threat detection neural networks.',
          suggestedRedline: {
            proposedText: 'Customer retains all right, title, and interest in and to Customer Data. Provider shall not use Customer Data, telemetry, or logs to train, fine-tune, or benchmark any AI model.',
            diffMarkup: '<del>Provider may ingest...</del> <ins>Customer retains all right... Provider shall not use...</ins>',
            rationale: 'Prevents trade secret contamination and telemetry exposure.',
            fallbackPosition: 'Permit aggregated statistical latency metrics only.',
            accepted: false,
          }
        }
      ];
    }

    const newContract: LegalContract = {
      id: `contract-${newMatter.id}`,
      matterId: newMatter.id,
      title: `${newMatter.title.toUpperCase()} (VENDOR DRAFT)`,
      contractType: newMatter.practiceArea,
      counterparty: newMatter.counterparty,
      effectiveDate: new Date().toISOString().split('T')[0],
      overallRiskScore: initialScore,
      highRiskCount: clauses.filter(c => c.riskSeverity === 'HIGH').length,
      medRiskCount: clauses.filter(c => c.riskSeverity === 'MEDIUM').length,
      lowRiskCount: clauses.filter(c => c.riskSeverity === 'LOW').length,
      content: contractText,
      clauses,
      riskFlags: [],
      version: 'v1.0 (Initial Intake)',
      lastModified: 'Just now',
    };

    setMatters(prev => [newMatter, ...prev]);
    setContracts(prev => ({
      ...prev,
      [newMatter.id]: newContract,
    }));
    setActiveMatter(newMatter);
    setActiveClauseId(clauses[0]?.id || null);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-600 selection:text-white">
      {/* Top Header & Matter Bar */}
      <Header
        matters={matters}
        activeMatter={activeMatter}
        onSelectMatter={handleSelectMatter}
        onOpenDmsModal={() => setIsDmsModalOpen(true)}
        onOpenPrecedentsModal={() => setIsPrecedentsModalOpen(true)}
        onOpenPrivilegeModal={() => setIsPrivilegeModalOpen(true)}
        onOpenRedactionModal={() => setIsRedactionModalOpen(true)}
        onOpenExecutiveSummary={() => setIsExecutiveSummaryOpen(true)}
        onOpenMatterDossier={() => setIsMatterDossierOpen(true)}
        onOpenNewMatterModal={() => setIsNewMatterModalOpen(true)}
        onToggleCopilot={() => setIsCopilotOpen(!isCopilotOpen)}
        isCopilotOpen={isCopilotOpen}
        isRedactionActive={isRedactionActive}
        onToggleRedaction={() => setIsRedactionActive(!isRedactionActive)}
      />

      {/* Privilege & Confidentiality Classification Ribbon */}
      <PrivilegeBanner
        matter={activeMatter}
        isRedactionActive={isRedactionActive}
        onOpenPrivilegeModal={() => setIsPrivilegeModalOpen(true)}
        onOpenRedactionModal={() => setIsRedactionModalOpen(true)}
      />

      {/* Main Dual-Pane Workspace */}
      <main className="flex-1 flex flex-col lg:flex-row min-h-0 overflow-hidden relative">
        {/* Left Pane: Interactive Contract Document Viewer */}
        <ContractViewer
          contract={activeContract}
          activeClauseId={activeClauseId}
          onSelectClause={(id) => setActiveClauseId(id)}
          onAcceptRedline={handleAcceptRedline}
          onUpdateContractContent={handleUpdateContractContent}
          onGenerateCustomRedline={handleGenerateCustomRedline}
          isRedactionActive={isRedactionActive}
        />

        {/* Right Pane: Risk Heatmap & Playbook Audit Panel */}
        <RiskHeatmapPanel
          contract={activeContract}
          activeClauseId={activeClauseId}
          onSelectClause={(id) => setActiveClauseId(id)}
          onAcceptRedline={handleAcceptRedline}
          onOpenPrecedentDetail={(p) => {
            setSelectedPrecedentForDetail(p);
            setIsPrecedentsModalOpen(true);
          }}
          onOpenPrecedentsModal={() => setIsPrecedentsModalOpen(true)}
          precedents={precedents}
        />

        {/* Gemini 3.8 Flash Counsel Copilot Drawer */}
        <CounselCopilot
          isOpen={isCopilotOpen}
          onClose={() => setIsCopilotOpen(false)}
          matter={activeMatter}
          contract={activeContract}
        />
      </main>

      {/* Modals */}
      <DmsIntegrationModal
        isOpen={isDmsModalOpen}
        onClose={() => setIsDmsModalOpen(false)}
        matter={activeMatter}
        onUpdateDms={handleUpdateDms}
      />

      <PrecedentSearchModal
        isOpen={isPrecedentsModalOpen}
        onClose={() => setIsPrecedentsModalOpen(false)}
        precedents={precedents}
        selectedPrecedent={selectedPrecedentForDetail}
        onApplyPrecedent={handleApplyPrecedent}
      />

      <PrivilegeLogModal
        isOpen={isPrivilegeModalOpen}
        onClose={() => setIsPrivilegeModalOpen(false)}
        matter={activeMatter}
      />

      <RedactionInspectorModal
        isOpen={isRedactionModalOpen}
        onClose={() => setIsRedactionModalOpen(false)}
        isRedactionActive={isRedactionActive}
        onToggleRedaction={() => setIsRedactionActive(!isRedactionActive)}
      />

      <ExecutiveSummaryModal
        isOpen={isExecutiveSummaryOpen}
        onClose={() => setIsExecutiveSummaryOpen(false)}
        matter={activeMatter}
        contract={activeContract}
      />

      <MatterDossierModal
        isOpen={isMatterDossierOpen}
        onClose={() => setIsMatterDossierOpen(false)}
        matter={activeMatter}
        onOpenDmsModal={() => setIsDmsModalOpen(true)}
      />

      <NewMatterModal
        isOpen={isNewMatterModalOpen}
        onClose={() => setIsNewMatterModalOpen(false)}
        onCreateMatter={handleCreateNewMatter}
      />
    </div>
  );
}
