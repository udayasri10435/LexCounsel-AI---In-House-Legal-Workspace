export type RiskSeverity = 'HIGH' | 'MEDIUM' | 'LOW' | 'STANDARD';

export type PracticeArea = 
  | 'Commercial & SaaS'
  | 'Corporate & M&A'
  | 'IP & Technology'
  | 'Employment & Labor'
  | 'Privacy & Data Security'
  | 'Vendor Procurement';

export type PrivilegeLevel = 
  | 'ATTORNEY-CLIENT PRIVILEGED'
  | 'ATTORNEY WORK PRODUCT'
  | 'CONFIDENTIAL - IN-HOUSE COUNSEL ONLY'
  | 'INTERNAL NON-PRIVILEGED';

export type DmsType = 'iManage' | 'NetDocuments' | 'Local Vault';

export interface DmsMetadata {
  provider: DmsType;
  workspaceId: string;
  workspaceName: string;
  documentId: string;
  documentNumber: string;
  version: number;
  isCheckedOut: boolean;
  checkedOutBy?: string;
  lastSyncedAt: string;
  cabinetOrDatabase: string;
}

export interface Matter {
  id: string;
  matterNumber: string; // e.g., "MAT-2026-0894"
  title: string;
  practiceArea: PracticeArea;
  leadCounsel: string;
  clientBusinessUnit: string; // e.g. "Enterprise Sales", "Cloud Engineering", "Finance"
  businessOwner: string; // e.g. "EVP Operations"
  counterparty: string;
  status: 'In Review' | 'Redlining' | 'Vendor Counter' | 'Escalated to GC' | 'Approved for Signature' | 'Executed';
  privilegeLevel: PrivilegeLevel;
  riskTolerance: 'Low (Aggressive Protection)' | 'Moderate (Balanced)' | 'High (Expedited Close)';
  dms: DmsMetadata;
  createdAt: string;
  targetClosingDate: string;
}

export interface Clause {
  id: string;
  title: string;
  category: 
    | 'Limitation of Liability'
    | 'Indemnification'
    | 'IP Ownership & Licensing'
    | 'Termination & Cure'
    | 'Confidentiality'
    | 'Data Privacy & Security'
    | 'Warranties & Disclaimers'
    | 'Governing Law & Dispute Resolution'
    | 'Insurance & Audit'
    | 'Non-Solicitation & Restrictive';
  clauseNumber: string; // e.g., "Section 8.2"
  originalText: string;
  lineNumberStart: number;
  lineNumberEnd: number;
  riskSeverity: RiskSeverity;
  riskSummary: string;
  playbookStandard: string;
  playbookDeviation: string;
  suggestedRedline: {
    proposedText: string;
    diffMarkup: string; // HTML or markdown formatted diff
    rationale: string;
    fallbackPosition: string;
    accepted: boolean;
  };
}

export interface RiskFlag {
  id: string;
  clauseId: string;
  clauseTitle: string;
  sectionNumber: string;
  severity: RiskSeverity;
  issueTitle: string;
  explanation: string;
  financialExposure: string; // e.g., "Uncapped exposure on third-party patent claims"
  recommendedAction: string;
  playbookRule: string;
  counselNotes?: string;
}

export interface Precedent {
  id: string;
  title: string;
  counterparty: string;
  matterNumber: string;
  practiceArea: PracticeArea;
  governingLaw: string;
  negotiatedDate: string;
  similarityScore: number; // 0 - 100
  clauseCategory: string;
  negotiatedText: string;
  concessionNotes: string; // e.g., "Vendor agreed to 2x trailing 12mo ARR super-cap for IP indemnity only"
  leadCounselName: string;
  dmsDocId: string;
}

export interface LegalContract {
  id: string;
  matterId: string;
  title: string;
  contractType: string;
  counterparty: string;
  effectiveDate: string;
  overallRiskScore: number; // 0 - 100 (higher = riskier)
  highRiskCount: number;
  medRiskCount: number;
  lowRiskCount: number;
  content: string;
  clauses: Clause[];
  riskFlags: RiskFlag[];
  version: string;
  lastModified: string;
}

export interface RedactionRule {
  type: 'PII_NAME' | 'FINANCIAL_AMOUNTS' | 'SECRET_CODENAME' | 'CONFIDENTIAL_METRICS' | 'CUSTOM';
  label: string;
  regex: string;
  mask: string;
  enabled: boolean;
}

export interface PrivilegeLogEntry {
  id: string;
  timestamp: string;
  matterNumber: string;
  documentTitle: string;
  author: string;
  recipients: string[];
  privilegeBasis: 'Attorney-Client Privilege' | 'Attorney Work Product' | 'Joint Defense Privilege';
  descriptionOfContent: string;
  redactionsApplied: number;
}
