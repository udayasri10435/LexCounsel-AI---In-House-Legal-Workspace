import { Matter, PracticeArea } from '../types/legal';

export interface AnalysisResponse {
  source: string;
  overallRiskScore?: number;
  executiveSummary?: string;
  extractedClauses?: Array<{
    category: string;
    title: string;
    clauseNumber: string;
    riskSeverity: 'HIGH' | 'MEDIUM' | 'LOW';
    riskSummary: string;
    playbookDeviation: string;
    proposedRedline: string;
    negotiationRationale: string;
    fallbackPosition: string;
  }>;
  summary?: string;
  riskScore?: number;
  clausesDetected?: number;
  highRiskFlags?: number;
}

export async function analyzeContractAPI(
  contractText: string,
  matter: Matter
): Promise<AnalysisResponse> {
  const response = await fetch('/api/analyze-contract', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contractText,
      matterTitle: matter.title,
      practiceArea: matter.practiceArea,
      riskTolerance: matter.riskTolerance,
    }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.details || err.error || 'Failed to analyze contract');
  }

  return response.json();
}

export async function generateRedlineAPI(
  clauseCategory: string,
  originalText: string,
  playbookRule: string,
  fallbackRequested: boolean = false
): Promise<{
  proposedText: string;
  diffSummary?: string;
  counselRationale?: string;
  talkTrackForVendor?: string;
  redlineText?: string;
  rationale?: string;
}> {
  const response = await fetch('/api/generate-redline', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      clauseCategory,
      originalText,
      playbookRule,
      fallbackRequested,
    }),
  });

  if (!response.ok) {
    throw new Error('Failed to generate AI redline');
  }

  return response.json();
}

export async function askCounselCopilotAPI(
  query: string,
  contractContext: string,
  matterDetails: Matter
): Promise<string> {
  const response = await fetch('/api/counsel-copilot', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      query,
      contractContext,
      matterDetails,
    }),
  });

  if (!response.ok) {
    throw new Error('Failed to communicate with Counsel Copilot');
  }

  const data = await response.json();
  return data.response;
}

export async function syncDmsAPI(
  provider: string,
  workspaceId: string,
  documentNumber: string,
  version: number,
  action: 'sync' | 'checkout' | 'save_new_version'
) {
  const response = await fetch('/api/dms/sync', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      provider,
      workspaceId,
      documentNumber,
      version,
      action,
    }),
  });

  if (!response.ok) {
    throw new Error('DMS synchronization failed');
  }

  return response.json();
}
